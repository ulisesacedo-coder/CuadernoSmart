# Agenda Inteligente v4

Versión preparada para compilar con GitHub Actions.

Incluye:
- Calendario mensual inspirado en la referencia visual.
- Indicadores separados para eventos, notas y ambos.
- Día actual y día de la semana seleccionado destacados.
- Crear eventos y notas desde el calendario.
- Notas asociadas a fechas.
- Editor de notas a pantalla completa.
- Menú principal con Panel y Notas eliminadas.
- Papelera de notas: restauración o eliminación definitiva; retención visual de 180 días.
- Icono propio de la aplicación.
- Respaldo de eventos y notas mediante el selector de archivos de Android, compatible con Google Drive cuando está disponible como proveedor.
- Modo oscuro.
- Java/Kotlin 17.

El flujo de GitHub descomprime el ZIP, encuentra automáticamente el proyecto y genera `app-debug.apk`.


## Versión 6.0
- Icono de Notas con bolígrafo de lujo.
- Timeline diario basado en la fecha seleccionada del calendario.
- Eventos y notas se muestran en la línea del tiempo.
- Retención de notas eliminadas: 180 días.
