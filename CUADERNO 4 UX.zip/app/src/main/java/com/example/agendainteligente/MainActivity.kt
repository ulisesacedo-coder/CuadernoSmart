package com.example.agendainteligente

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.platform.LocalContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStream
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale
import java.util.UUID

private val Blue = Color(0xFF1976D2)
private val Purple = Color(0xFF5E35B1)
private val Orange = Color(0xFFFF9800)
private val Page = Color(0xFFF8F6FB)
private val Muted = Color(0xFF77747D)
private val Danger = Color(0xFFD32F2F)
private val Spanish = Locale("es", "MX")
private const val RETENTION_DAYS = 180L

private fun dateText(date: LocalDate): String =
    date.format(DateTimeFormatter.ofPattern("EEEE d 'de' MMMM 'de' yyyy", Spanish))
        .replaceFirstChar { it.uppercase() }

private fun monthText(month: YearMonth): String =
    month.month.getDisplayName(TextStyle.FULL, Spanish).replaceFirstChar { it.uppercase() }

data class AgendaEvent(
    val id: String = UUID.randomUUID().toString(),
    val date: String,
    val title: String,
    val time: String = "09:00",
    val description: String = "",
    val reminder: Boolean = false
)

data class Note(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val body: String,
    val pinned: Boolean = false,
    val date: String? = null,
    val colorHex: String = "#FFF9BF",
    val updatedAt: Long = System.currentTimeMillis()
)

data class DeletedNote(val note: Note, val deletedAt: Long = System.currentTimeMillis())

class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("agenda_store", Context.MODE_PRIVATE)

    fun events(): List<AgendaEvent> = try {
        val array = JSONArray(prefs.getString("events", "[]") ?: "[]")
        (0 until array.length()).map { index ->
            val x = array.getJSONObject(index)
            AgendaEvent(
                id = x.optString("id"),
                date = x.optString("date"),
                title = x.optString("title"),
                time = x.optString("time"),
                description = x.optString("description"),
                reminder = x.optBoolean("reminder")
            )
        }
    } catch (_: Exception) { emptyList() }

    fun saveEvents(items: List<AgendaEvent>) {
        val array = JSONArray()
        items.forEach { event ->
            array.put(JSONObject().apply {
                put("id", event.id)
                put("date", event.date)
                put("title", event.title)
                put("time", event.time)
                put("description", event.description)
                put("reminder", event.reminder)
            })
        }
        prefs.edit().putString("events", array.toString()).apply()
    }

    fun notes(): List<Note> = try {
        val array = JSONArray(prefs.getString("notes", "[]") ?: "[]")
        (0 until array.length()).map { index ->
            val x = array.getJSONObject(index)
            Note(
                id = x.optString("id"),
                title = x.optString("title"),
                body = x.optString("body"),
                pinned = x.optBoolean("pinned"),
                date = x.optString("date").ifBlank { null },
                colorHex = x.optString("colorHex", "#FFF9BF"),
                updatedAt = x.optLong("updatedAt", System.currentTimeMillis())
            )
        }
    } catch (_: Exception) { emptyList() }

    fun saveNotes(items: List<Note>) {
        val array = JSONArray()
        items.forEach { note ->
            array.put(JSONObject().apply {
                put("id", note.id)
                put("title", note.title)
                put("body", note.body)
                put("pinned", note.pinned)
                put("date", note.date ?: "")
                put("updatedAt", note.updatedAt)
            })
        }
        prefs.edit().putString("notes", array.toString()).apply()
    }

    fun deletedNotes(): List<DeletedNote> {
        val cutoff = System.currentTimeMillis() - RETENTION_DAYS * 24L * 60L * 60L * 1000L
        return try {
            val array = JSONArray(prefs.getString("deleted_notes", "[]") ?: "[]")
            (0 until array.length()).mapNotNull { index ->
                val x = array.getJSONObject(index)
                val deletedAt = x.optLong("deletedAt", 0L)
                if (deletedAt < cutoff) return@mapNotNull null
                val note = Note(
                    id = x.optString("id"),
                    title = x.optString("title"),
                    body = x.optString("body"),
                    pinned = x.optBoolean("pinned"),
                    date = x.optString("date").ifBlank { null },
                    colorHex = x.optString("colorHex", "#FFF9BF"),
                    updatedAt = x.optLong("updatedAt", System.currentTimeMillis())
                )
                DeletedNote(note, deletedAt)
            }
        } catch (_: Exception) { emptyList() }
    }

    fun saveDeletedNotes(items: List<DeletedNote>) {
        val cutoff = System.currentTimeMillis() - RETENTION_DAYS * 24L * 60L * 60L * 1000L
        val valid = items.filter { it.deletedAt >= cutoff }
        val array = JSONArray()
        valid.forEach { deleted ->
            array.put(JSONObject().apply {
                put("id", deleted.note.id)
                put("title", deleted.note.title)
                put("body", deleted.note.body)
                put("pinned", deleted.note.pinned)
                put("date", deleted.note.date ?: "")
                put("colorHex", deleted.note.colorHex)
                put("updatedAt", deleted.note.updatedAt)
                put("deletedAt", deleted.deletedAt)
            })
        }
        prefs.edit().putString("deleted_notes", array.toString()).apply()
    }

    fun dark(): Boolean = prefs.getBoolean("dark", false)
    fun setDark(value: Boolean) = prefs.edit().putBoolean("dark", value).apply()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AgendaApp(LocalStore(this)) }
    }
}

@Composable
fun AgendaApp(store: LocalStore) {
    val context = LocalContext.current
    var dark by remember { mutableStateOf(store.dark()) }
    var tab by remember { mutableIntStateOf(0) }
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    var month by remember { mutableStateOf(YearMonth.now()) }
    var events by remember { mutableStateOf(store.events()) }
    var notes by remember { mutableStateOf(store.notes()) }
    var deleted by remember { mutableStateOf(store.deletedNotes()) }
    var menuOpen by remember { mutableStateOf(false) }
    var panelOpen by remember { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }
    var driveOpen by remember { mutableStateOf(false) }
    var quickOpen by remember { mutableStateOf(false) }
    var deletedOpen by remember { mutableStateOf(false) }
    var eventEditor by remember { mutableStateOf<AgendaEvent?>(null) }
    var eventDetail by remember { mutableStateOf<AgendaEvent?>(null) }
    var noteEditor by remember { mutableStateOf<Note?>(null) }
    var fullNote by remember { mutableStateOf<Note?>(null) }

    val backupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            val root = JSONObject()
            val eventArray = JSONArray()
            events.forEach { e ->
                eventArray.put(JSONObject().apply {
                    put("id", e.id); put("date", e.date); put("title", e.title)
                    put("time", e.time); put("description", e.description); put("reminder", e.reminder)
                })
            }
            val noteArray = JSONArray()
            notes.forEach { n ->
                noteArray.put(JSONObject().apply {
                    put("id", n.id); put("title", n.title); put("body", n.body)
                    put("pinned", n.pinned); put("date", n.date ?: ""); put("colorHex", n.colorHex); put("updatedAt", n.updatedAt)
                })
            }
            root.put("version", 2)
            root.put("events", eventArray)
            root.put("notes", noteArray)
            val bytes = root.toString(2).toByteArray(Charsets.UTF_8)
            try {
                context.contentResolver.openOutputStream(uri)?.use { stream: OutputStream -> stream.write(bytes) }
            } catch (_: Exception) { }
        }
    }

    val colors = if (dark) darkColorScheme(primary = Blue) else lightColorScheme(primary = Blue)
    MaterialTheme(colorScheme = colors) {
        Scaffold(
            containerColor = if (dark) Color(0xFF111116) else Page,
            bottomBar = { BottomBar(tab) { tab = it } }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Header(
                    onMenu = { menuOpen = true },
                    onPanel = { panelOpen = true },
                    onSettings = { settingsOpen = true },
                    onRocket = { quickOpen = true }
                )
                if (tab == 0) {
                    HomeScreen(
                        selectedDate = selectedDate, events = events, notes = notes,
                        onCreate = { quickOpen = true },
                        onCalendar = { tab = 1 }, onNotes = { tab = 2 }, onMore = { menuOpen = true },
                        onEvent = { eventDetail = it }, onNote = { fullNote = it }
                    )
                } else if (tab == 1) {
                    CalendarScreen(
                        month = month,
                        selectedDate = selectedDate,
                        events = events,
                        notes = notes,
                        onPrevious = { month = month.minusMonths(1) },
                        onNext = { month = month.plusMonths(1) },
                        onDateSelected = { selectedDate = it },
                        onNewEvent = { eventEditor = AgendaEvent(date = selectedDate.toString(), title = "") },
                        onNewNote = { noteEditor = Note(title = "", body = "", date = selectedDate.toString()) },
                        onEditEvent = { eventDetail = it },
                        onEditNote = { fullNote = it },
                        onDeleteEvent = { event ->
                            events = events.filterNot { it.id == event.id }; store.saveEvents(events)
                        },
                        onDeleteNote = { note ->
                            notes = notes.filterNot { it.id == note.id }
                            deleted = (deleted + DeletedNote(note)).takeLast(100)
                            store.saveNotes(notes); store.saveDeletedNotes(deleted)
                        }
                    )
                } else if (tab == 2) {
                    NotesScreen(
                        notes = notes,
                        onNew = { noteEditor = Note(title = "", body = "") },
                        onEdit = { fullNote = it },
                        onDelete = { note ->
                            notes = notes.filterNot { it.id == note.id }
                            deleted = (deleted + DeletedNote(note)).takeLast(100)
                            store.saveNotes(notes); store.saveDeletedNotes(deleted)
                        },
                        onPin = { note ->
                            notes = notes.map { current ->
                                if (current.id == note.id) current.copy(pinned = !current.pinned, updatedAt = System.currentTimeMillis()) else current
                            }.sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.updatedAt })
                            store.saveNotes(notes)
                        }
                    )
                } else {
                    MoreScreen(
                        onPanel = { panelOpen = true },
                        onDeleted = { deletedOpen = true },
                        onDrive = { driveOpen = true },
                        onSettings = { settingsOpen = true }
                    )
                }
            }
        }
    }

    if (menuOpen) AppMenu(
        onDismiss = { menuOpen = false },
        onHome = { menuOpen = false; tab = 0 },
        onCalendar = { menuOpen = false; tab = 1 },
        onNotes = { menuOpen = false; tab = 2 },
        onDeleted = { menuOpen = false; deletedOpen = true },
        onPanel = { menuOpen = false; panelOpen = true },
        onDrive = { menuOpen = false; driveOpen = true },
        onSettings = { menuOpen = false; settingsOpen = true }
    )
    if (panelOpen) PanelDialog(events, notes) { panelOpen = false }
    if (settingsOpen) SettingsDialog(dark, { value -> dark = value; store.setDark(value) }) { settingsOpen = false }
    if (quickOpen) QuickActionsDialog(
        onNewEvent = { quickOpen = false; eventEditor = AgendaEvent(date = selectedDate.toString(), title = "") },
        onNewNote = { quickOpen = false; noteEditor = Note(title = "", body = "", date = selectedDate.toString()) },
        onDrive = { quickOpen = false; driveOpen = true },
        onDismiss = { quickOpen = false }
    )
    if (driveOpen) DriveDialog(
        onBackup = { backupLauncher.launch("Notas_backup.json"); driveOpen = false },
        onDismiss = { driveOpen = false }
    )
    if (deletedOpen) DeletedNotesDialog(
        deleted = deleted,
        onRestore = { item ->
            deleted = deleted.filterNot { it.note.id == item.note.id }
            notes = (notes + item.note).distinctBy { it.id }
                .sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.updatedAt })
            store.saveDeletedNotes(deleted); store.saveNotes(notes)
        },
        onPermanentDelete = { item ->
            deleted = deleted.filterNot { it.note.id == item.note.id }; store.saveDeletedNotes(deleted)
        },
        onDismiss = { deletedOpen = false }
    )
    eventDetail?.let { event ->
        EventDetailDialog(
            event = event,
            onEdit = { eventDetail = null; eventEditor = event },
            onDelete = {
                events = events.filterNot { it.id == event.id }
                store.saveEvents(events)
                eventDetail = null
            },
            onDismiss = { eventDetail = null }
        )
    }
    eventEditor?.let { original ->
        EventDialog(original, onDismiss = { eventEditor = null }) { edited ->
            events = (events.filterNot { it.id == edited.id } + edited)
                .sortedWith(compareBy<AgendaEvent> { it.date }.thenBy { it.time })
            store.saveEvents(events); eventEditor = null
        }
    }
    noteEditor?.let { original ->
        NoteDialog(original, onDismiss = { noteEditor = null }) { edited ->
            notes = (notes.filterNot { it.id == edited.id } + edited)
                .sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.updatedAt })
            store.saveNotes(notes); noteEditor = null
        }
    }
    fullNote?.let { original ->
        FullScreenNote(
            note = original,
            onClose = { fullNote = null },
            onSave = { edited ->
                notes = (notes.filterNot { it.id == edited.id } + edited)
                    .sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.updatedAt })
                store.saveNotes(notes); fullNote = null
            },
            onDelete = { note ->
                notes = notes.filterNot { it.id == note.id }
                deleted = (deleted + DeletedNote(note)).takeLast(100)
                store.saveNotes(notes); store.saveDeletedNotes(deleted); fullNote = null
            }
        )
    }
}

@Composable
private fun Header(onMenu: () -> Unit, onPanel: () -> Unit, onSettings: () -> Unit, onRocket: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(78.dp).background(MaterialTheme.colorScheme.surface).padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onMenu) { Icon(Icons.Default.Menu, "Menú") }
        Column(Modifier.weight(1f).clickable { onMenu() }) {
            Text("Agenda S", fontFamily = FontFamily.Cursive, fontSize = 31.sp, fontWeight = FontWeight.SemiBold, color = Blue)
            Text("Tu vida en orden", fontSize = 11.sp, color = Muted)
        }
        IconButton(onClick = onPanel) { Icon(Icons.Default.Dashboard, "Resumen") }
        IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Configuración") }
        Surface(Modifier.size(46.dp), CircleShape, color = Blue) {
            IconButton(onClick = onRocket) { Icon(Icons.Default.Add, "Crear nuevo", tint = Color.White) }
        }
    }
}

@Composable
private fun Workspace(onClick: () -> Unit) {
    Surface(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 9.dp).clickable { onClick() },
        RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Sync, null, tint = Muted); Spacer(Modifier.width(14.dp)); Text("Hogar", fontSize = 18.sp)
            Spacer(Modifier.weight(1f)); Icon(Icons.Default.KeyboardArrowDown, null, tint = Muted)
        }
    }
}

@Composable
private fun HomeScreen(
    selectedDate: LocalDate, events: List<AgendaEvent>, notes: List<Note>,
    onCreate: () -> Unit, onCalendar: () -> Unit, onNotes: () -> Unit, onMore: () -> Unit,
    onEvent: (AgendaEvent) -> Unit, onNote: (Note) -> Unit
) {
    val todayEvents = events.filter { it.date == selectedDate.toString() }.sortedBy { it.time }.take(4)
    val recentNotes = notes.sortedByDescending { it.updatedAt }.take(3)
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Agenda S", fontFamily = FontFamily.Cursive, fontSize = 43.sp, color = Blue)
            Text("Tu vida en orden", fontSize = 13.sp, color = Muted)
            Spacer(Modifier.height(4.dp))
            Text("¡Hola! 👋", fontSize = 27.sp, fontWeight = FontWeight.Bold)
            Text(dateText(selectedDate), color = Muted)
        }
        item {
            Text("Organiza hoy, logra mañana.", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                QuickHomeButton(Icons.Default.Event, "Evento", Blue, onCreate)
                QuickHomeButton(Icons.Default.TaskAlt, "Tarea", Color(0xFF25A86B), onCreate)
                QuickHomeButton(Icons.Default.NoteAdd, "Nota", Orange, onNotes)
                QuickHomeButton(Icons.Default.Notifications, "Aviso", Purple, onCreate)
            }
        }
        item {
            Surface(Modifier.fillMaxWidth(), RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surface) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Próximas actividades", fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        TextButton(onClick = onCalendar) { Text("Ver todas") }
                    }
                    if (todayEvents.isEmpty()) Text("No tienes actividades para hoy.", color = Muted)
                    todayEvents.forEach { e ->
                        Row(Modifier.fillMaxWidth().clickable { onEvent(e) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(e.time, fontWeight = FontWeight.Bold, modifier = Modifier.width(58.dp))
                            Box(Modifier.size(9.dp).clip(CircleShape).background(Blue))
                            Spacer(Modifier.width(10.dp))
                            Column { Text(e.title, fontWeight = FontWeight.SemiBold); if (e.description.isNotBlank()) Text(e.description, color = Muted, fontSize = 12.sp) }
                        }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HomeStatCard("Notas", notes.size.toString(), "en total", Icons.Default.Description, onNotes, Modifier.weight(1f))
                HomeStatCard("Eventos", events.size.toString(), "programados", Icons.Default.CalendarMonth, onCalendar, Modifier.weight(1f))
            }
        }
        item {
            Text("Notas recientes", fontSize = 19.sp, fontWeight = FontWeight.Bold)
        }
        items(recentNotes, key = { it.id }) { n ->
            NoteCard(n, onNote, {}, {})
        }
    }
}

@Composable private fun QuickHomeButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, tint: Color, onClick: () -> Unit) {
    Column(Modifier.weight(1f).clickable { onClick() }, horizontalAlignment = Alignment.CenterHorizontally) {
        Surface(Modifier.size(52.dp), CircleShape, color = tint.copy(alpha = .13f)) { Box(contentAlignment = Alignment.Center) { Icon(icon, null, tint = tint) } }
        Spacer(Modifier.height(4.dp)); Text(label, fontSize = 12.sp)
    }
}

@Composable private fun HomeStatCard(title: String, number: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, modifier: Modifier) {
    Surface(modifier.clickable { onClick() }, RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.padding(15.dp)) { Icon(icon, null, tint = Blue); Spacer(Modifier.height(5.dp)); Text(title, fontWeight = FontWeight.SemiBold); Text(number, fontSize = 26.sp, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, fontSize = 11.sp) }
    }
}

@Composable private fun MoreScreen(onPanel: () -> Unit, onDeleted: () -> Unit, onDrive: () -> Unit, onSettings: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Más", fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Text("Herramientas de Agenda S", color = Muted)
        Spacer(Modifier.height(18.dp))
        MenuItem(Icons.Default.Dashboard, "Panel y resumen", onPanel)
        MenuItem(Icons.Default.DeleteOutline, "Papelera de notas", onDeleted)
        MenuItem(Icons.Default.CloudUpload, "Respaldo en Google Drive", onDrive)
        MenuItem(Icons.Default.Settings, "Configuración", onSettings)
    }
}

@Composable
private fun CalendarScreen(
    month: YearMonth, selectedDate: LocalDate, events: List<AgendaEvent>, notes: List<Note>,
    onPrevious: () -> Unit, onNext: () -> Unit, onDateSelected: (LocalDate) -> Unit,
    onNewEvent: () -> Unit, onNewNote: () -> Unit, onEditEvent: (AgendaEvent) -> Unit,
    onEditNote: (Note) -> Unit, onDeleteEvent: (AgendaEvent) -> Unit, onDeleteNote: (Note) -> Unit
) {
    val dayEvents = events.filter { it.date == selectedDate.toString() }.sortedBy { it.time }
    val dayNotes = notes.filter { it.date == selectedDate.toString() }
    Column(Modifier.fillMaxSize()) {
        Text("MI AGENDA", Modifier.padding(start = 24.dp, top = 24.dp), fontSize = 13.sp, color = Muted, fontWeight = FontWeight.Bold)
        Text("Calendario", Modifier.padding(start = 24.dp, top = 3.dp), fontSize = 38.sp, fontWeight = FontWeight.Bold)
        Surface(Modifier.padding(horizontal = 20.dp, vertical = 14.dp), RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.padding(horizontal = 10.dp, vertical = 16.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onPrevious) { Icon(Icons.Default.ArrowBack, "Mes anterior", tint = Blue) }
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(monthText(month), textAlign = TextAlign.Center, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Text("Toca un día para ver sus actividades", fontSize = 10.sp, color = Muted)
                    }
                    TextButton(onClick = { onDateSelected(LocalDate.now()) }) { Text("Hoy") }
                    IconButton(onClick = onNext) { Icon(Icons.Default.ArrowForward, "Mes siguiente", tint = Blue) }
                }
                CalendarGrid(month, selectedDate, events, notes, onDateSelected)
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.Center) {
                    LegendDot(Blue, "Eventos"); Spacer(Modifier.width(16.dp)); LegendDot(Purple, "Notas")
                }
            }
        }
        Text(dateText(selectedDate), Modifier.padding(horizontal = 28.dp, vertical = 4.dp), fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onNewEvent, Modifier.weight(1f).height(50.dp), shape = RoundedCornerShape(16.dp)) {
                Icon(Icons.Default.Event, null); Spacer(Modifier.width(6.dp)); Text("Agregar evento")
            }
            Button(onClick = onNewNote, Modifier.weight(1f).height(50.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange)) {
                Icon(Icons.Default.NoteAdd, null); Spacer(Modifier.width(6.dp)); Text("Agregar nota")
            }
        }
        TimelineDay(dayEvents, dayNotes, onEditEvent, onDeleteEvent, onEditNote, onDeleteNote)
    }
}

@Composable
private fun CalendarGrid(month: YearMonth, selectedDate: LocalDate, events: List<AgendaEvent>, notes: List<Note>, onDateSelected: (LocalDate) -> Unit) {
    val first = month.atDay(1)
    val start = first.dayOfWeek.value % 7
    val headers = listOf("D", "L", "M", "X", "J", "V", "S")
    Column {
        Row(Modifier.fillMaxWidth()) {
            headers.forEachIndexed { index, header ->
                val selectedHeader = selectedDate.year == month.year && selectedDate.month == month.month && selectedDate.dayOfWeek.value % 7 == index
                Text(header, Modifier.weight(1f).padding(vertical = 7.dp), textAlign = TextAlign.Center, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (selectedHeader) Blue else Muted)
            }
        }
        var day = 1
        repeat(6) { week ->
            Row(Modifier.fillMaxWidth().height(52.dp)) {
                repeat(7) { col ->
                    val index = week * 7 + col
                    Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                        if (index >= start && day <= month.lengthOfMonth()) {
                            val date = month.atDay(day)
                            val selected = date == selectedDate
                            val today = date == LocalDate.now()
                            val hasEvent = events.any { it.date == date.toString() }
                            val hasNote = notes.any { it.date == date.toString() }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    Modifier.size(if (selected) 40.dp else 36.dp).clip(CircleShape)
                                        .background(if (selected) Blue else if (today) Color(0xFFE7F0FF) else Color.Transparent)
                                        .clickable { onDateSelected(date) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(day.toString(), color = if (selected) Color.White else if (today) Blue else MaterialTheme.colorScheme.onSurface, fontWeight = if (selected || today) FontWeight.Bold else FontWeight.Normal)
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                    if (hasEvent) Box(Modifier.size(4.dp).clip(CircleShape).background(Blue))
                                    if (hasNote) Box(Modifier.size(4.dp).clip(CircleShape).background(Purple))
                                }
                            }
                            day++
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun LegendDot(color: Color, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(7.dp).clip(CircleShape).background(color)); Spacer(Modifier.width(4.dp)); Text(text, fontSize = 11.sp, color = Muted) }
}

@Composable
private fun TimelineDay(events: List<AgendaEvent>, notes: List<Note>, onEditEvent: (AgendaEvent) -> Unit, onDeleteEvent: (AgendaEvent) -> Unit, onEditNote: (Note) -> Unit, onDeleteNote: (Note) -> Unit) {
    val entries = buildList<Pair<String, @Composable () -> Unit>> {
        events.forEach { event ->
            add(event.time to { EventTimelineCard(event, onEditEvent, onDeleteEvent) })
        }
        notes.forEach { note ->
            add((note.updatedAt.toString()) to { NoteTimelineCard(note, onEditNote, onDeleteNote) })
        }
    }.sortedBy { it.first }
    if (entries.isEmpty()) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Tu día está libre", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text("Agrega un evento o una nota con los botones de arriba.", color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center)
        }
    } else {
        LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = 16.dp)) {
            items(entries.size) { index -> entries[index].second() }
        }
    }
}

@Composable private fun EventTimelineCard(event: AgendaEvent, onEdit: (AgendaEvent) -> Unit, onDelete: (AgendaEvent) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 5.dp), verticalAlignment = Alignment.Top) {
        Column(Modifier.width(56.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(event.time.ifBlank { "--" }, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Muted)
            Box(Modifier.padding(top = 5.dp).size(10.dp).clip(CircleShape).background(Blue))
            Box(Modifier.width(2.dp).height(65.dp).background(Blue.copy(alpha = .18f)))
        }
        Surface(Modifier.weight(1f).clickable { onEdit(event) }, RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(event.title.ifBlank { "Evento" }, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    if (event.description.isNotBlank()) Text(event.description, color = Muted, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
                }
                IconButton(onClick = { onDelete(event) }) { Icon(Icons.Default.DeleteOutline, "Eliminar", tint = Danger) }
            }
        }
    }
}

@Composable private fun NoteTimelineCard(note: Note, onEdit: (Note) -> Unit, onDelete: (Note) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 5.dp), verticalAlignment = Alignment.Top) {
        Column(Modifier.width(56.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Nota", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Muted)
            Box(Modifier.padding(top = 5.dp).size(10.dp).clip(CircleShape).background(Purple))
            Box(Modifier.width(2.dp).height(65.dp).background(Purple.copy(alpha = .18f)))
        }
        Surface(Modifier.weight(1f).clickable { onEdit(note) }, RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(note.title.ifBlank { "Nota" }, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    if (note.body.isNotBlank()) Text(note.body, color = Muted, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
                }
                IconButton(onClick = { onDelete(note) }) { Icon(Icons.Default.DeleteOutline, "Eliminar", tint = Danger) }
            }
        }
    }
}

@Composable
private fun NotesScreen(notes: List<Note>, onNew: () -> Unit, onEdit: (Note) -> Unit, onDelete: (Note) -> Unit, onPin: (Note) -> Unit) {
    var query by remember { mutableStateOf("") }
    var newestFirst by remember { mutableStateOf(true) }
    val filtered = notes
        .filter { it.title.contains(query, true) || it.body.contains(query, true) }
        .sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { if (newestFirst) it.updatedAt else -it.updatedAt })

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Notas", fontSize = 28.sp, fontWeight = FontWeight.Bold, Modifier.weight(1f))
            IconButton(onClick = onNew) { Icon(Icons.Default.Add, "Nueva nota", tint = Orange) }
        }
        Surface(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            RoundedCornerShape(2.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            TextButton(
                onClick = { newestFirst = !newestFirst },
                Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                Text(if (newestFirst) "Ordenar por fecha de modificación" else "Ordenar por fecha de modificación · más antiguas primero", fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                Spacer(Modifier.width(8.dp))
                Icon(Icons.Default.KeyboardArrowDown, "Cambiar orden", tint = MaterialTheme.colorScheme.onSurface)
            }
        }
        OutlinedTextField(
            value = query, onValueChange = { query = it }, placeholder = { Text("Buscar notas") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            trailingIcon = { if (query.isNotEmpty()) TextButton(onClick = { query = "" }) { Text("Limpiar") } },
            modifier = Modifier.fillMaxWidth().padding(10.dp, 10.dp, 10.dp, 4.dp).height(54.dp),
            shape = RoundedCornerShape(10.dp),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                focusedContainerColor = MaterialTheme.colorScheme.surface
            ),
            singleLine = true
        )
        if (filtered.isEmpty()) {
            Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Icon(Icons.Default.Description, null, modifier = Modifier.size(54.dp), tint = Muted)
                Spacer(Modifier.height(10.dp))
                Text(if (query.isBlank()) "Aún no tienes notas" else "No encontramos notas", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(if (query.isBlank()) "Toca + para crear tu primera nota." else "Prueba con otra palabra.", color = Muted, textAlign = TextAlign.Center)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 4.dp, bottom = 90.dp)) {
                items(filtered, key = { it.id }) { note -> NoteCard(note, onEdit, onDelete, onPin) }
            }
        }
    }
}

@Composable private fun NoteCard(note: Note, onEdit: (Note) -> Unit, onDelete: (Note) -> Unit, onPin: (Note) -> Unit) {
    val bg = runCatching { Color(android.graphics.Color.parseColor(note.colorHex)) }.getOrElse { Color(0xFFFFF9BF) }
    val accent = if (note.pinned) Blue else bg.copy(alpha = .82f)
    val dateLabel = java.time.Instant.ofEpochMilli(note.updatedAt).atZone(java.time.ZoneId.systemDefault()).toLocalDate()
        .format(DateTimeFormatter.ofPattern("d MMM\nyyyy", Spanish))
    Surface(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 3.dp).clickable { onEdit(note) },
        RoundedCornerShape(2.dp), color = bg
    ) {
        Row(Modifier.heightIn(min = 76.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(7.dp).fillMaxHeight().background(accent))
            Text(
                note.title.ifBlank { "Sin título" },
                Modifier.weight(1f).padding(start = 14.dp, end = 8.dp),
                fontSize = 20.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            if (note.pinned) Icon(Icons.Default.PushPin, "Fijada", modifier = Modifier.size(20.dp), tint = accent)
            Text(dateLabel, Modifier.padding(horizontal = 12.dp), fontSize = 14.sp, color = Muted, textAlign = TextAlign.Center, lineHeight = 17.sp)
            IconButton(onClick = { onDelete(note) }) { Icon(Icons.Default.DeleteOutline, "Eliminar", tint = Danger) }
        }
    }
}

@Composable private fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
        NavigationBarItem(selected == 0, { onSelect(0) }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Inicio") })
        NavigationBarItem(selected == 1, { onSelect(1) }, icon = { Icon(Icons.Default.CalendarMonth, null) }, label = { Text("Calendario") })
        NavigationBarItem(selected == 2, { onSelect(2) }, icon = { Icon(Icons.Default.Description, null) }, label = { Text("Notas") })
        NavigationBarItem(selected == 3, { onSelect(3) }, icon = { Icon(Icons.Default.MoreVert, null) }, label = { Text("Más") })
    }
}

@Composable private fun AppMenu(onDismiss: () -> Unit, onHome: () -> Unit, onCalendar: () -> Unit, onNotes: () -> Unit, onDeleted: () -> Unit, onPanel: () -> Unit, onDrive: () -> Unit, onSettings: () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxHeight().fillMaxWidth(.86f), RoundedCornerShape(topEnd = 28.dp, bottomEnd = 28.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.fillMaxSize().padding(20.dp)) {
                Text("Agenda S", fontFamily = FontFamily.Cursive, fontSize = 30.sp, fontWeight = FontWeight.SemiBold, color = Blue)
                Text("Tu agenda personal", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(20.dp))
                MenuItem(Icons.Default.Home, "Inicio", onHome)
                MenuItem(Icons.Default.CalendarMonth, "Calendario", onCalendar)
                MenuItem(Icons.Default.Description, "Notas", onNotes)
                MenuItem(Icons.Default.DeleteOutline, "Notas eliminadas", onDeleted)
                MenuItem(Icons.Default.Dashboard, "Panel", onPanel)
                HorizontalDivider(Modifier.padding(vertical = 10.dp))
                MenuItem(Icons.Default.CloudUpload, "Sincronizar con Google Drive", onDrive)
                MenuItem(Icons.Default.Settings, "Configuración", onSettings)
            }
        }
    }
}

@Composable private fun MenuItem(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Blue); Spacer(Modifier.width(14.dp)); Text(text, fontSize = 16.sp)
    }
}

@Composable private fun PanelDialog(events: List<AgendaEvent>, notes: List<Note>, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Panel") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("${events.size} eventos", fontWeight = FontWeight.SemiBold)
            Text("${notes.size} notas")
            Text("${notes.count { it.pinned }} notas fijadas")
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } })
}

@Composable private fun SettingsDialog(dark: Boolean, onDark: (Boolean) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Configuración") }, text = {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (dark) Icons.Default.DarkMode else Icons.Default.LightMode, null)
            Spacer(Modifier.width(12.dp)); Text("Modo oscuro", Modifier.weight(1f)); Switch(checked = dark, onCheckedChange = onDark)
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } })
}

@Composable private fun QuickActionsDialog(onNewEvent: () -> Unit, onNewNote: () -> Unit, onDrive: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Crear nuevo") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onNewEvent, Modifier.fillMaxWidth()) { Icon(Icons.Default.Event, null); Spacer(Modifier.width(8.dp)); Text("Nuevo evento") }
            Button(onClick = onNewNote, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Orange)) { Icon(Icons.Default.NoteAdd, null); Spacer(Modifier.width(8.dp)); Text("Nueva nota") }
            OutlinedButton(onClick = onDrive, Modifier.fillMaxWidth()) { Icon(Icons.Default.CloudUpload, null); Spacer(Modifier.width(8.dp)); Text("Guardar respaldo") }
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } })
}

@Composable private fun DriveDialog(onBackup: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Google Drive") }, text = {
        Text("Guarda un respaldo de tus eventos y notas. Al elegir la ubicación, Android puede mostrar Google Drive si está disponible en tu teléfono.")
    }, confirmButton = { Button(onClick = onBackup) { Text("Guardar respaldo") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } })
}

@Composable private fun DeletedNotesDialog(deleted: List<DeletedNote>, onRestore: (DeletedNote) -> Unit, onPermanentDelete: (DeletedNote) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Notas eliminadas") }, text = {
        Column(Modifier.fillMaxWidth().heightIn(max = 430.dp)) {
            if (deleted.isEmpty()) Text("No hay notas eliminadas.", color = Muted)
            else LazyColumn {
                items(deleted, key = { it.note.id }) { item ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.DeleteOutline, null, tint = Danger); Spacer(Modifier.width(7.dp))
                        Column(Modifier.weight(1f)) { Text(item.note.title.ifBlank { "Sin título" }, fontWeight = FontWeight.Bold); Text("Retención: 180 días", fontSize = 11.sp, color = Muted) }
                        TextButton(onClick = { onRestore(item) }) { Text("Restaurar") }
                        IconButton(onClick = { onPermanentDelete(item) }) { Icon(Icons.Default.DeleteForever, "Eliminar definitivamente", tint = Danger) }
                    }
                }
            }
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } })
}

@Composable
private fun EventDetailDialog(event: AgendaEvent, onEdit: () -> Unit, onDelete: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(event.title.ifBlank { "Evento" }, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CalendarMonth, null, tint = Blue)
                    Spacer(Modifier.width(10.dp))
                    Text(runCatching { LocalDate.parse(event.date).format(DateTimeFormatter.ofPattern("EEEE d 'de' MMMM 'de' yyyy", Spanish)) }.getOrDefault(event.date))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Event, null, tint = Blue)
                    Spacer(Modifier.width(10.dp))
                    Text("${event.time.ifBlank { "Sin hora" }}${if (event.reminder) " · Recordatorio activado" else ""}")
                }
                if (event.description.isNotBlank()) {
                    HorizontalDivider()
                    Text(event.description, fontSize = 16.sp, lineHeight = 23.sp)
                } else {
                    Text("Sin descripción", color = Muted, fontSize = 14.sp)
                }
            }
        },
        confirmButton = {
            Button(onClick = onEdit) { Text("Editar") }
        },
        dismissButton = {
            Row {
                TextButton(onClick = onDelete) { Text("Eliminar", color = Danger) }
                TextButton(onClick = onDismiss) { Text("Cerrar") }
            }
        }
    )
}

@Composable private fun EventDialog(original: AgendaEvent, onDismiss: () -> Unit, onSave: (AgendaEvent) -> Unit) {
    var title by remember(original.id) { mutableStateOf(original.title) }
    var date by remember(original.id) { mutableStateOf(original.date) }
    var time by remember(original.id) { mutableStateOf(original.time) }
    var description by remember(original.id) { mutableStateOf(original.description) }
    var reminder by remember(original.id) { mutableStateOf(original.reminder) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (original.title.isBlank()) "Nuevo evento" else "Editar evento") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Título") }, singleLine = true)
            OutlinedTextField(value = date, onValueChange = { date = it }, label = { Text("Fecha AAAA-MM-DD") }, singleLine = true)
            OutlinedTextField(value = time, onValueChange = { time = it }, label = { Text("Hora") }, singleLine = true)
            OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Descripción") }, minLines = 2)
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = reminder, onCheckedChange = { reminder = it }); Text("Recordatorio") }
        }
    }, confirmButton = {
        TextButton(onClick = {
            if (title.isNotBlank() && runCatching { LocalDate.parse(date) }.isSuccess) onSave(original.copy(title = title, date = date, time = time, description = description, reminder = reminder))
        }) { Text("Guardar") }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}

@Composable private fun NoteDialog(original: Note, onDismiss: () -> Unit, onSave: (Note) -> Unit) {
    var title by remember(original.id) { mutableStateOf(original.title) }
    var body by remember(original.id) { mutableStateOf(original.body) }
    var date by remember(original.id) { mutableStateOf(original.date ?: "") }
    var pinned by remember(original.id) { mutableStateOf(original.pinned) }
    var colorHex by remember(original.id) { mutableStateOf(original.colorHex) }
    val palette = listOf("#FFF9BF", "#FFE0E6", "#DFF7E5", "#DDF0FF", "#E8DEFF", "#FFE5D0", "#E5E7EB")
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (original.title.isBlank()) "Nueva nota" else "Editar nota") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Título") }, singleLine = true)
            OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text("Contenido") }, minLines = 5)
            OutlinedTextField(value = date, onValueChange = { date = it }, label = { Text("Fecha AAAA-MM-DD, opcional") }, singleLine = true)
            Text("Color de la nota", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                palette.forEach { hex ->
                    Box(Modifier.size(28.dp).clip(CircleShape).background(Color(android.graphics.Color.parseColor(hex))).clickable { colorHex = hex }, contentAlignment = Alignment.Center) {
                        if (colorHex == hex) Text("✓", fontWeight = FontWeight.Bold)
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = pinned, onCheckedChange = { pinned = it }); Text("Fijar nota") }
        }
    }, confirmButton = {
        TextButton(onClick = {
            val valid = title.isNotBlank() && (date.isBlank() || runCatching { LocalDate.parse(date) }.isSuccess)
            if (valid) onSave(original.copy(title = title, body = body, date = date.ifBlank { null }, pinned = pinned, colorHex = colorHex, updatedAt = System.currentTimeMillis()))
        }) { Text("Guardar") }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}

@Composable private fun FullScreenNote(note: Note, onClose: () -> Unit, onSave: (Note) -> Unit, onDelete: (Note) -> Unit) {
    var title by remember(note.id) { mutableStateOf(note.title) }
    var body by remember(note.id) { mutableStateOf(note.body) }
    var colorHex by remember(note.id) { mutableStateOf(note.colorHex) }
    val palette = listOf("#FFF9BF", "#FFE0E6", "#DFF7E5", "#DDF0FF", "#E8DEFF", "#FFE5D0", "#E5E7EB")
    val noteColor = runCatching { Color(android.graphics.Color.parseColor(colorHex)) }.getOrElse { Color(0xFFFFF9BF) }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Surface(Modifier.fillMaxSize(), color = noteColor) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().height(76.dp).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.Default.ArrowBack, "Cerrar") }
                    OutlinedTextField(
                        value = title, onValueChange = { title = it }, modifier = Modifier.weight(1f),
                        singleLine = true, textStyle = LocalTextStyle.current.copy(fontSize = 18.sp),
                        placeholder = { Text("Título") }, shape = RoundedCornerShape(2.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    IconButton(onClick = { onSave(note.copy(title = title, body = body, colorHex = colorHex, updatedAt = System.currentTimeMillis())) }) {
                        Text("✓", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    }
                    IconButton(onClick = { onDelete(note) }) { Icon(Icons.Default.DeleteOutline, "Eliminar", tint = Danger) }
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Editando", color = Muted, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Text(java.time.LocalDate.now().format(DateTimeFormatter.ofPattern("d/M/yy", Spanish)), color = Muted, fontSize = 13.sp)
                }
                OutlinedTextField(
                    value = body, onValueChange = { body = it }, modifier = Modifier.fillMaxWidth().weight(1f).padding(horizontal = 10.dp),
                    placeholder = { Text("Escribe aquí...", fontSize = 18.sp) },
                    textStyle = LocalTextStyle.current.copy(fontSize = 18.sp, lineHeight = 38.sp),
                    colors = OutlinedTextFieldDefaults.colors(unfocusedContainerColor = noteColor, focusedContainerColor = noteColor, unfocusedBorderColor = Color.Transparent, focusedBorderColor = Color.Transparent),
                    minLines = 12
                )
                HorizontalDivider(color = Color.Black.copy(alpha = .18f))
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.CenterVertically) {
                    palette.forEach { hex ->
                        Box(Modifier.size(31.dp).clip(CircleShape).background(Color(android.graphics.Color.parseColor(hex))).clickable { colorHex = hex }, contentAlignment = Alignment.Center) {
                            if (colorHex == hex) Text("✓", fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp, ), horizontalArrangement = Arrangement.SpaceAround) {
                    IconButton(onClick = {}) { Icon(Icons.Default.Undo, "Deshacer") }
                    IconButton(onClick = {}) { Icon(Icons.Default.Redo, "Rehacer", tint = Muted) }
                    IconButton(onClick = { }) { Icon(Icons.Default.Notifications, "Recordatorio") }
                    IconButton(onClick = { onDelete(note) }) { Icon(Icons.Default.DeleteOutline, "Eliminar", tint = Danger) }
                }
            }
        }
    }
}

