package com.example.agendainteligente

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.platform.LocalContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStream
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale
import java.util.UUID

private val Blue = Color(0xFF1976D2)
private val Purple = Color(0xFF5E35B1)
private val Orange = Color(0xFFFF9800)
private val Page = Color(0xFFF8F6FB)
private val Muted = Color(0xFF77747D)
private val Danger = Color(0xFFD32F2F)
private val Spanish = Locale("es", "MX")
private const val RETENTION_DAYS = 180L

private fun dateText(date: LocalDate): String =
    date.format(DateTimeFormatter.ofPattern("EEEE d 'de' MMMM 'de' yyyy", Spanish))
        .replaceFirstChar { it.uppercase() }

private fun monthText(month: YearMonth): String =
    month.month.getDisplayName(TextStyle.FULL, Spanish).replaceFirstChar { it.uppercase() }

data class AgendaEvent(
    val id: String = UUID.randomUUID().toString(),
    val date: String,
    val title: String,
    val time: String = "09:00",
    val description: String = "",
    val reminder: Boolean = false
)

data class Note(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val body: String,
    val pinned: Boolean = false,
    val date: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
)

data class DeletedNote(val note: Note, val deletedAt: Long = System.currentTimeMillis())

class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("agenda_store", Context.MODE_PRIVATE)

    fun events(): List<AgendaEvent> = try {
        val array = JSONArray(prefs.getString("events", "[]") ?: "[]")
        (0 until array.length()).map { index ->
            val x = array.getJSONObject(index)
            AgendaEvent(
                id = x.optString("id"),
                date = x.optString("date"),
                title = x.optString("title"),
                time = x.optString("time"),
                description = x.optString("description"),
                reminder = x.optBoolean("reminder")
            )
        }
    } catch (_: Exception) { emptyList() }

    fun saveEvents(items: List<AgendaEvent>) {
        val array = JSONArray()
        items.forEach { event ->
            array.put(JSONObject().apply {
                put("id", event.id)
                put("date", event.date)
                put("title", event.title)
                put("time", event.time)
                put("description", event.description)
                put("reminder", event.reminder)
            })
        }
        prefs.edit().putString("events", array.toString()).apply()
    }

    fun notes(): List<Note> = try {
        val array = JSONArray(prefs.getString("notes", "[]") ?: "[]")
        (0 until array.length()).map { index ->
            val x = array.getJSONObject(index)
            Note(
                id = x.optString("id"),
                title = x.optString("title"),
                body = x.optString("body"),
                pinned = x.optBoolean("pinned"),
                date = x.optString("date").ifBlank { null },
                updatedAt = x.optLong("updatedAt", System.currentTimeMillis())
            )
        }
    } catch (_: Exception) { emptyList() }

    fun saveNotes(items: List<Note>) {
        val array = JSONArray()
        items.forEach { note ->
            array.put(JSONObject().apply {
                put("id", note.id)
                put("title", note.title)
                put("body", note.body)
                put("pinned", note.pinned)
                put("date", note.date ?: "")
                put("updatedAt", note.updatedAt)
            })
        }
        prefs.edit().putString("notes", array.toString()).apply()
    }

    fun deletedNotes(): List<DeletedNote> {
        val cutoff = System.currentTimeMillis() - RETENTION_DAYS * 24L * 60L * 60L * 1000L
        return try {
            val array = JSONArray(prefs.getString("deleted_notes", "[]") ?: "[]")
            (0 until array.length()).mapNotNull { index ->
                val x = array.getJSONObject(index)
                val deletedAt = x.optLong("deletedAt", 0L)
                if (deletedAt < cutoff) return@mapNotNull null
                val note = Note(
                    id = x.optString("id"),
                    title = x.optString("title"),
                    body = x.optString("body"),
                    pinned = x.optBoolean("pinned"),
                    date = x.optString("date").ifBlank { null },
                    updatedAt = x.optLong("updatedAt", System.currentTimeMillis())
                )
                DeletedNote(note, deletedAt)
            }
        } catch (_: Exception) { emptyList() }
    }

    fun saveDeletedNotes(items: List<DeletedNote>) {
        val cutoff = System.currentTimeMillis() - RETENTION_DAYS * 24L * 60L * 60L * 1000L
        val valid = items.filter { it.deletedAt >= cutoff }
        val array = JSONArray()
        valid.forEach { deleted ->
            array.put(JSONObject().apply {
                put("id", deleted.note.id)
                put("title", deleted.note.title)
                put("body", deleted.note.body)
                put("pinned", deleted.note.pinned)
                put("date", deleted.note.date ?: "")
                put("updatedAt", deleted.note.updatedAt)
                put("deletedAt", deleted.deletedAt)
            })
        }
        prefs.edit().putString("deleted_notes", array.toString()).apply()
    }

    fun dark(): Boolean = prefs.getBoolean("dark", false)
    fun setDark(value: Boolean) = prefs.edit().putBoolean("dark", value).apply()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AgendaApp(LocalStore(this)) }
    }
}

@Composable
fun AgendaApp(store: LocalStore) {
    val context = LocalContext.current
    var dark by remember { mutableStateOf(store.dark()) }
    var tab by remember { mutableIntStateOf(0) }
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    var month by remember { mutableStateOf(YearMonth.now()) }
    var events by remember { mutableStateOf(store.events()) }
    var notes by remember { mutableStateOf(store.notes()) }
    var deleted by remember { mutableStateOf(store.deletedNotes()) }
    var menuOpen by remember { mutableStateOf(false) }
    var panelOpen by remember { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }
    var driveOpen by remember { mutableStateOf(false) }
    var quickOpen by remember { mutableStateOf(false) }
    var deletedOpen by remember { mutableStateOf(false) }
    var eventEditor by remember { mutableStateOf<AgendaEvent?>(null) }
    var noteEditor by remember { mutableStateOf<Note?>(null) }
    var fullNote by remember { mutableStateOf<Note?>(null) }

    val backupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            val root = JSONObject()
            val eventArray = JSONArray()
            events.forEach { e ->
                eventArray.put(JSONObject().apply {
                    put("id", e.id); put("date", e.date); put("title", e.title)
                    put("time", e.time); put("description", e.description); put("reminder", e.reminder)
                })
            }
            val noteArray = JSONArray()
            notes.forEach { n ->
                noteArray.put(JSONObject().apply {
                    put("id", n.id); put("title", n.title); put("body", n.body)
                    put("pinned", n.pinned); put("date", n.date ?: ""); put("updatedAt", n.updatedAt)
                })
            }
            root.put("version", 2)
            root.put("events", eventArray)
            root.put("notes", noteArray)
            val bytes = root.toString(2).toByteArray(Charsets.UTF_8)
            try {
                context.contentResolver.openOutputStream(uri)?.use { stream: OutputStream -> stream.write(bytes) }
            } catch (_: Exception) { }
        }
    }

    val colors = if (dark) darkColorScheme(primary = Blue) else lightColorScheme(primary = Blue)
    MaterialTheme(colorScheme = colors) {
        Scaffold(
            containerColor = if (dark) Color(0xFF111116) else Page,
            bottomBar = { BottomBar(tab) { tab = it } }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Header(
                    onMenu = { menuOpen = true },
                    onPanel = { panelOpen = true },
                    onSettings = { settingsOpen = true },
                    onRocket = { quickOpen = true }
                )
                Workspace(onClick = { menuOpen = true })
                if (tab == 0) {
                    CalendarScreen(
                        month = month,
                        selectedDate = selectedDate,
                        events = events,
                        notes = notes,
                        onPrevious = { month = month.minusMonths(1) },
                        onNext = { month = month.plusMonths(1) },
                        onDateSelected = { selectedDate = it },
                        onNewEvent = { eventEditor = AgendaEvent(date = selectedDate.toString(), title = "") },
                        onNewNote = { noteEditor = Note(title = "", body = "", date = selectedDate.toString()) },
                        onEditEvent = { eventEditor = it },
                        onEditNote = { fullNote = it },
                        onDeleteEvent = { event ->
                            events = events.filterNot { it.id == event.id }; store.saveEvents(events)
                        },
                        onDeleteNote = { note ->
                            notes = notes.filterNot { it.id == note.id }
                            deleted = (deleted + DeletedNote(note)).takeLast(100)
                            store.saveNotes(notes); store.saveDeletedNotes(deleted)
                        }
                    )
                } else {
                    NotesScreen(
                        notes = notes,
                        onNew = { noteEditor = Note(title = "", body = "") },
                        onEdit = { fullNote = it },
                        onDelete = { note ->
                            notes = notes.filterNot { it.id == note.id }
                            deleted = (deleted + DeletedNote(note)).takeLast(100)
                            store.saveNotes(notes); store.saveDeletedNotes(deleted)
                        },
                        onPin = { note ->
                            notes = notes.map { current ->
                                if (current.id == note.id) current.copy(pinned = !current.pinned, updatedAt = System.currentTimeMillis()) else current
                            }.sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.updatedAt })
                            store.saveNotes(notes)
                        }
                    )
                }
            }
        }
    }

    if (menuOpen) AppMenu(
        onDismiss = { menuOpen = false },
        onCalendar = { menuOpen = false; tab = 0 },
        onNotes = { menuOpen = false; tab = 1 },
        onDeleted = { menuOpen = false; deletedOpen = true },
        onPanel = { menuOpen = false; panelOpen = true },
        onDrive = { menuOpen = false; driveOpen = true },
        onSettings = { menuOpen = false; settingsOpen = true }
    )
    if (panelOpen) PanelDialog(events, notes) { panelOpen = false }
    if (settingsOpen) SettingsDialog(dark, { value -> dark = value; store.setDark(value) }) { settingsOpen = false }
    if (quickOpen) QuickActionsDialog(
        onNewEvent = { quickOpen = false; eventEditor = AgendaEvent(date = selectedDate.toString(), title = "") },
        onNewNote = { quickOpen = false; noteEditor = Note(title = "", body = "", date = selectedDate.toString()) },
        onDrive = { quickOpen = false; driveOpen = true },
        onDismiss = { quickOpen = false }
    )
    if (driveOpen) DriveDialog(
        onBackup = { backupLauncher.launch("Notas_backup.json"); driveOpen = false },
        onDismiss = { driveOpen = false }
    )
    if (deletedOpen) DeletedNotesDialog(
        deleted = deleted,
        onRestore = { item ->
            deleted = deleted.filterNot { it.note.id == item.note.id }
            notes = (notes + item.note).distinctBy { it.id }
                .sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.updatedAt })
            store.saveDeletedNotes(deleted); store.saveNotes(notes)
        },
        onPermanentDelete = { item ->
            deleted = deleted.filterNot { it.note.id == item.note.id }; store.saveDeletedNotes(deleted)
        },
        onDismiss = { deletedOpen = false }
    )
    eventEditor?.let { original ->
        EventDialog(original, onDismiss = { eventEditor = null }) { edited ->
            events = (events.filterNot { it.id == edited.id } + edited)
                .sortedWith(compareBy<AgendaEvent> { it.date }.thenBy { it.time })
            store.saveEvents(events); eventEditor = null
        }
    }
    noteEditor?.let { original ->
        NoteDialog(original, onDismiss = { noteEditor = null }) { edited ->
            notes = (notes.filterNot { it.id == edited.id } + edited)
                .sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.updatedAt })
            store.saveNotes(notes); noteEditor = null
        }
    }
    fullNote?.let { original ->
        FullScreenNote(
            note = original,
            onClose = { fullNote = null },
            onSave = { edited ->
                notes = (notes.filterNot { it.id == edited.id } + edited)
                    .sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.updatedAt })
                store.saveNotes(notes); fullNote = null
            },
            onDelete = { note ->
                notes = notes.filterNot { it.id == note.id }
                deleted = (deleted + DeletedNote(note)).takeLast(100)
                store.saveNotes(notes); store.saveDeletedNotes(deleted); fullNote = null
            }
        )
    }
}

@Composable
private fun Header(onMenu: () -> Unit, onPanel: () -> Unit, onSettings: () -> Unit, onRocket: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(72.dp).background(MaterialTheme.colorScheme.surface).padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(Modifier.size(40.dp).clickable { onMenu() }, CircleShape, color = Orange) {
            Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.EventAvailable, null, tint = Color.White) }
        }
        Spacer(Modifier.width(12.dp))
        Surface(Modifier.clickable { onMenu() }, RoundedCornerShape(9.dp), color = Color(0xFFE9E7E2)) {
            Text("Avance", Modifier.padding(horizontal = 13.dp, vertical = 8.dp), fontSize = 15.sp)
        }
        Text("Panel", Modifier.padding(horizontal = 12.dp).clickable { onPanel() }, fontSize = 15.sp)
        Spacer(Modifier.weight(1f))
        IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Configuración") }
        Surface(Modifier.size(44.dp), RoundedCornerShape(9.dp), color = Color(0xFF111111)) {
            IconButton(onClick = onRocket) { Icon(Icons.Default.RocketLaunch, "Acciones rápidas", tint = Color.White) }
        }
    }
}

@Composable
private fun Workspace(onClick: () -> Unit) {
    Surface(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 9.dp).clickable { onClick() },
        RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Sync, null, tint = Muted); Spacer(Modifier.width(14.dp)); Text("Hogar", fontSize = 18.sp)
            Spacer(Modifier.weight(1f)); Icon(Icons.Default.KeyboardArrowDown, null, tint = Muted)
        }
    }
}

@Composable
private fun CalendarScreen(
    month: YearMonth, selectedDate: LocalDate, events: List<AgendaEvent>, notes: List<Note>,
    onPrevious: () -> Unit, onNext: () -> Unit, onDateSelected: (LocalDate) -> Unit,
    onNewEvent: () -> Unit, onNewNote: () -> Unit, onEditEvent: (AgendaEvent) -> Unit,
    onEditNote: (Note) -> Unit, onDeleteEvent: (AgendaEvent) -> Unit, onDeleteNote: (Note) -> Unit
) {
    val dayEvents = events.filter { it.date == selectedDate.toString() }.sortedBy { it.time }
    val dayNotes = notes.filter { it.date == selectedDate.toString() }
    Column(Modifier.fillMaxSize()) {
        Text("MI AGENDA", Modifier.padding(start = 24.dp, top = 24.dp), fontSize = 13.sp, color = Muted, fontWeight = FontWeight.Bold)
        Text("Calendario", Modifier.padding(start = 24.dp, top = 3.dp), fontSize = 38.sp, fontWeight = FontWeight.Bold)
        Surface(Modifier.padding(horizontal = 20.dp, vertical = 14.dp), RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.padding(horizontal = 10.dp, vertical = 16.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onPrevious) { Icon(Icons.Default.ArrowBack, "Mes anterior", tint = Blue) }
                    Text(monthText(month), Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    IconButton(onClick = onNext) { Icon(Icons.Default.ArrowForward, "Mes siguiente", tint = Blue) }
                }
                CalendarGrid(month, selectedDate, events, notes, onDateSelected)
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.Center) {
                    LegendDot(Blue, "Eventos"); Spacer(Modifier.width(16.dp)); LegendDot(Purple, "Notas")
                }
            }
        }
        Text(dateText(selectedDate), Modifier.padding(horizontal = 28.dp), fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onNewEvent, Modifier.weight(1f).height(50.dp), shape = RoundedCornerShape(25.dp)) {
                Icon(Icons.Default.Event, null); Spacer(Modifier.width(6.dp)); Text("Evento")
            }
            Button(onClick = onNewNote, Modifier.weight(1f).height(50.dp), shape = RoundedCornerShape(25.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange)) {
                Icon(Icons.Default.NoteAdd, null); Spacer(Modifier.width(6.dp)); Text("Nota")
            }
        }
        TimelineDay(dayEvents, dayNotes, onEditEvent, onDeleteEvent, onEditNote, onDeleteNote)
    }
}

@Composable
private fun CalendarGrid(month: YearMonth, selectedDate: LocalDate, events: List<AgendaEvent>, notes: List<Note>, onDateSelected: (LocalDate) -> Unit) {
    val first = month.atDay(1)
    val start = first.dayOfWeek.value % 7
    val headers = listOf("D", "L", "M", "X", "J", "V", "S")
    Column {
        Row(Modifier.fillMaxWidth()) {
            headers.forEachIndexed { index, header ->
                val selectedHeader = selectedDate.year == month.year && selectedDate.month == month.month && selectedDate.dayOfWeek.value % 7 == index
                Text(header, Modifier.weight(1f).padding(vertical = 7.dp), textAlign = TextAlign.Center, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (selectedHeader) Blue else Muted)
            }
        }
        var day = 1
        repeat(6) { week ->
            Row(Modifier.fillMaxWidth().height(52.dp)) {
                repeat(7) { col ->
                    val index = week * 7 + col
                    Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                        if (index >= start && day <= month.lengthOfMonth()) {
                            val date = month.atDay(day)
                            val selected = date == selectedDate
                            val today = date == LocalDate.now()
                            val hasEvent = events.any { it.date == date.toString() }
                            val hasNote = notes.any { it.date == date.toString() }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    Modifier.size(if (selected) 40.dp else 36.dp).clip(CircleShape)
                                        .background(if (selected) Blue else if (today) Color(0xFFE7F0FF) else Color.Transparent)
                                        .clickable { onDateSelected(date) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(day.toString(), color = if (selected) Color.White else if (today) Blue else MaterialTheme.colorScheme.onSurface, fontWeight = if (selected || today) FontWeight.Bold else FontWeight.Normal)
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                    if (hasEvent) Box(Modifier.size(4.dp).clip(CircleShape).background(Blue))
                                    if (hasNote) Box(Modifier.size(4.dp).clip(CircleShape).background(Purple))
                                }
                            }
                            day++
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun LegendDot(color: Color, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(7.dp).clip(CircleShape).background(color)); Spacer(Modifier.width(4.dp)); Text(text, fontSize = 11.sp, color = Muted) }
}

@Composable
private fun TimelineDay(events: List<AgendaEvent>, notes: List<Note>, onEditEvent: (AgendaEvent) -> Unit, onDeleteEvent: (AgendaEvent) -> Unit, onEditNote: (Note) -> Unit, onDeleteNote: (Note) -> Unit) {
    val entries = buildList<Pair<String, @Composable () -> Unit>> {
        events.forEach { event ->
            add(event.time to { EventTimelineCard(event, onEditEvent, onDeleteEvent) })
        }
        notes.forEach { note ->
            add((note.updatedAt.toString()) to { NoteTimelineCard(note, onEditNote, onDeleteNote) })
        }
    }.sortedBy { it.first }
    if (entries.isEmpty()) {
        Text("Sin actividades para este día", Modifier.padding(horizontal = 28.dp, vertical = 16.dp), color = Muted)
    } else {
        LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = 16.dp)) {
            items(entries.size) { index -> entries[index].second() }
        }
    }
}

@Composable private fun EventTimelineCard(event: AgendaEvent, onEdit: (AgendaEvent) -> Unit, onDelete: (AgendaEvent) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 5.dp), verticalAlignment = Alignment.Top) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, Modifier.width(56.dp)) {
            Text(event.time.ifBlank { "--" }, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Muted)
            Box(Modifier.padding(top = 5.dp).size(10.dp).clip(CircleShape).background(Blue))
            Box(Modifier.width(2.dp).height(65.dp).background(Blue.copy(alpha = .18f)))
        }
        Surface(Modifier.weight(1f).clickable { onEdit(event) }, RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(event.title.ifBlank { "Evento" }, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    if (event.description.isNotBlank()) Text(event.description, color = Muted, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
                }
                IconButton(onClick = { onDelete(event) }) { Icon(Icons.Default.DeleteOutline, "Eliminar", tint = Danger) }
            }
        }
    }
}

@Composable private fun NoteTimelineCard(note: Note, onEdit: (Note) -> Unit, onDelete: (Note) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 5.dp), verticalAlignment = Alignment.Top) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, Modifier.width(56.dp)) {
            Text("Nota", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Muted)
            Box(Modifier.padding(top = 5.dp).size(10.dp).clip(CircleShape).background(Purple))
            Box(Modifier.width(2.dp).height(65.dp).background(Purple.copy(alpha = .18f)))
        }
        Surface(Modifier.weight(1f).clickable { onEdit(note) }, RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(note.title.ifBlank { "Nota" }, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    if (note.body.isNotBlank()) Text(note.body, color = Muted, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
                }
                IconButton(onClick = { onDelete(note) }) { Icon(Icons.Default.DeleteOutline, "Eliminar", tint = Danger) }
            }
        }
    }
}

@Composable
private fun NotesScreen(notes: List<Note>, onNew: () -> Unit, onEdit: (Note) -> Unit, onDelete: (Note) -> Unit, onPin: (Note) -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = notes.filter { it.title.contains(query, true) || it.body.contains(query, true) }
    Column(Modifier.fillMaxSize()) {
        Text("NOTAS", Modifier.padding(start = 24.dp, top = 24.dp), fontSize = 13.sp, color = Muted, fontWeight = FontWeight.Bold)
        Text("Notas", Modifier.padding(start = 24.dp, top = 3.dp), fontSize = 38.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = query, onValueChange = { query = it }, placeholder = { Text("Buscar notas") },
            leadingIcon = { Icon(Icons.Default.Search, null) }, modifier = Modifier.fillMaxWidth().padding(20.dp).height(58.dp),
            shape = RoundedCornerShape(30.dp), colors = OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedBorderColor = Color.Transparent
            ), singleLine = true
        )
        Button(onClick = onNew, Modifier.fillMaxWidth().padding(horizontal = 20.dp).height(56.dp), shape = RoundedCornerShape(28.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange)) {
            Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Nueva nota", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)) {
            items(filtered, key = { it.id }) { note -> NoteCard(note, onEdit, onDelete, onPin) }
        }
    }
}

@Composable private fun NoteCard(note: Note, onEdit: (Note) -> Unit, onDelete: (Note) -> Unit, onPin: (Note) -> Unit) {
    Surface(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp).clickable { onEdit(note) }, RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(note.title.ifBlank { "Sin título" }, Modifier.weight(1f), fontSize = 19.sp, fontWeight = FontWeight.Bold)
                IconButton(onClick = { onPin(note) }) { Icon(Icons.Default.PushPin, "Fijar", tint = if (note.pinned) Orange else Muted) }
                IconButton(onClick = { onDelete(note) }) { Icon(Icons.Default.DeleteOutline, "Eliminar", tint = Danger) }
            }
            Text(note.body, color = Muted, fontSize = 15.sp, maxLines = 4, overflow = TextOverflow.Ellipsis)
            note.date?.let { date -> Text(date, Modifier.padding(top = 9.dp), color = Blue, fontSize = 12.sp) }
        }
    }
}

@Composable private fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
        NavigationBarItem(selected == 0, { onSelect(0) }, icon = { Icon(Icons.Default.CalendarMonth, null) }, label = { Text("Calendario") })
        NavigationBarItem(selected == 1, { onSelect(1) }, icon = { Icon(Icons.Default.Description, null) }, label = { Text("Notas") })
    }
}

@Composable private fun AppMenu(onDismiss: () -> Unit, onCalendar: () -> Unit, onNotes: () -> Unit, onDeleted: () -> Unit, onPanel: () -> Unit, onDrive: () -> Unit, onSettings: () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxHeight().fillMaxWidth(.86f), RoundedCornerShape(topEnd = 28.dp, bottomEnd = 28.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.fillMaxSize().padding(20.dp)) {
                Text("Notas", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Organiza tu día", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(20.dp))
                MenuItem(Icons.Default.Home, "Inicio", onCalendar)
                MenuItem(Icons.Default.CalendarMonth, "Calendario", onCalendar)
                MenuItem(Icons.Default.Description, "Notas", onNotes)
                MenuItem(Icons.Default.DeleteOutline, "Notas eliminadas", onDeleted)
                MenuItem(Icons.Default.Dashboard, "Panel", onPanel)
                HorizontalDivider(Modifier.padding(vertical = 10.dp))
                MenuItem(Icons.Default.CloudUpload, "Sincronizar con Google Drive", onDrive)
                MenuItem(Icons.Default.Settings, "Configuración", onSettings)
            }
        }
    }
}

@Composable private fun MenuItem(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Blue); Spacer(Modifier.width(14.dp)); Text(text, fontSize = 16.sp)
    }
}

@Composable private fun PanelDialog(events: List<AgendaEvent>, notes: List<Note>, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Panel") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Eventos: ${events.size}")
            Text("Notas: ${notes.size}")
            Text("Notas fijadas: ${notes.count { it.pinned }}")
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } })
}

@Composable private fun SettingsDialog(dark: Boolean, onDark: (Boolean) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Configuración") }, text = {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (dark) Icons.Default.DarkMode else Icons.Default.LightMode, null)
            Spacer(Modifier.width(12.dp)); Text("Modo oscuro", Modifier.weight(1f)); Switch(checked = dark, onCheckedChange = onDark)
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } })
}

@Composable private fun QuickActionsDialog(onNewEvent: () -> Unit, onNewNote: () -> Unit, onDrive: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Acciones rápidas") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onNewEvent, Modifier.fillMaxWidth()) { Icon(Icons.Default.Event, null); Spacer(Modifier.width(8.dp)); Text("Nuevo evento") }
            Button(onClick = onNewNote, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Orange)) { Icon(Icons.Default.NoteAdd, null); Spacer(Modifier.width(8.dp)); Text("Nueva nota") }
            OutlinedButton(onClick = onDrive, Modifier.fillMaxWidth()) { Icon(Icons.Default.CloudUpload, null); Spacer(Modifier.width(8.dp)); Text("Respaldo") }
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } })
}

@Composable private fun DriveDialog(onBackup: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Google Drive") }, text = {
        Text("Guarda un respaldo de tus eventos y notas. Al elegir la ubicación, Android puede mostrar Google Drive si está disponible en tu teléfono.")
    }, confirmButton = { Button(onClick = onBackup) { Text("Guardar respaldo") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } })
}

@Composable private fun DeletedNotesDialog(deleted: List<DeletedNote>, onRestore: (DeletedNote) -> Unit, onPermanentDelete: (DeletedNote) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Notas eliminadas") }, text = {
        Column(Modifier.fillMaxWidth().heightIn(max = 430.dp)) {
            if (deleted.isEmpty()) Text("No hay notas eliminadas.", color = Muted)
            else LazyColumn {
                items(deleted, key = { it.note.id }) { item ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.DeleteOutline, null, tint = Danger); Spacer(Modifier.width(7.dp))
                        Column(Modifier.weight(1f)) { Text(item.note.title.ifBlank { "Sin título" }, fontWeight = FontWeight.Bold); Text("Retención: 180 días", fontSize = 11.sp, color = Muted) }
                        TextButton(onClick = { onRestore(item) }) { Text("Restaurar") }
                        IconButton(onClick = { onPermanentDelete(item) }) { Icon(Icons.Default.DeleteForever, "Eliminar definitivamente", tint = Danger) }
                    }
                }
            }
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } })
}

@Composable private fun EventDialog(original: AgendaEvent, onDismiss: () -> Unit, onSave: (AgendaEvent) -> Unit) {
    var title by remember(original.id) { mutableStateOf(original.title) }
    var date by remember(original.id) { mutableStateOf(original.date) }
    var time by remember(original.id) { mutableStateOf(original.time) }
    var description by remember(original.id) { mutableStateOf(original.description) }
    var reminder by remember(original.id) { mutableStateOf(original.reminder) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (original.title.isBlank()) "Nuevo evento" else "Editar evento") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Título") }, singleLine = true)
            OutlinedTextField(value = date, onValueChange = { date = it }, label = { Text("Fecha AAAA-MM-DD") }, singleLine = true)
            OutlinedTextField(value = time, onValueChange = { time = it }, label = { Text("Hora") }, singleLine = true)
            OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Descripción") }, minLines = 2)
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = reminder, onCheckedChange = { reminder = it }); Text("Recordatorio") }
        }
    }, confirmButton = {
        TextButton(onClick = {
            if (title.isNotBlank() && runCatching { LocalDate.parse(date) }.isSuccess) onSave(original.copy(title = title, date = date, time = time, description = description, reminder = reminder))
        }) { Text("Guardar") }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}

@Composable private fun NoteDialog(original: Note, onDismiss: () -> Unit, onSave: (Note) -> Unit) {
    var title by remember(original.id) { mutableStateOf(original.title) }
    var body by remember(original.id) { mutableStateOf(original.body) }
    var date by remember(original.id) { mutableStateOf(original.date ?: "") }
    var pinned by remember(original.id) { mutableStateOf(original.pinned) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (original.title.isBlank()) "Nueva nota" else "Editar nota") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Título") }, singleLine = true)
            OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text("Contenido") }, minLines = 5)
            OutlinedTextField(value = date, onValueChange = { date = it }, label = { Text("Fecha AAAA-MM-DD, opcional") }, singleLine = true)
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = pinned, onCheckedChange = { pinned = it }); Text("Fijar nota") }
        }
    }, confirmButton = {
        TextButton(onClick = {
            val valid = title.isNotBlank() && (date.isBlank() || runCatching { LocalDate.parse(date) }.isSuccess)
            if (valid) onSave(original.copy(title = title, body = body, date = date.ifBlank { null }, pinned = pinned, updatedAt = System.currentTimeMillis()))
        }) { Text("Guardar") }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}

@Composable private fun FullScreenNote(note: Note, onClose: () -> Unit, onSave: (Note) -> Unit, onDelete: (Note) -> Unit) {
    var title by remember(note.id) { mutableStateOf(note.title) }
    var body by remember(note.id) { mutableStateOf(note.body) }
    var date by remember(note.id) { mutableStateOf(note.date ?: "") }
    var pinned by remember(note.id) { mutableStateOf(note.pinned) }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.Default.ArrowBack, "Cerrar") }
                    Text("Nota", Modifier.weight(1f), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    IconButton(onClick = { onDelete(note) }) { Icon(Icons.Default.DeleteOutline, "Eliminar", tint = Danger) }
                }
                HorizontalDivider()
                Column(Modifier.fillMaxSize().padding(18.dp)) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Título") }, singleLine = true)
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(value = body, onValueChange = { body = it }, modifier = Modifier.fillMaxWidth().weight(1f), label = { Text("Contenido") }, textStyle = LocalTextStyle.current.copy(fontSize = 18.sp), minLines = 12)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = date, onValueChange = { date = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Fecha AAAA-MM-DD, opcional") }, singleLine = true)
                    Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = pinned, onCheckedChange = { pinned = it }); Text("Fijar nota") }
                    Button(onClick = {
                        val valid = title.isNotBlank() && (date.isBlank() || runCatching { LocalDate.parse(date) }.isSuccess)
                        if (valid) onSave(note.copy(title = title, body = body, date = date.ifBlank { null }, pinned = pinned, updatedAt = System.currentTimeMillis()))
                    }, Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(27.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                        Text("Guardar", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
