package com.example.agendainteligente

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale
import java.util.UUID

private val Blue = Color(0xFF246BFD)
private val Purple = Color(0xFF5B35D5)
private val Orange = Color(0xFFFF9800)
private val Page = Color(0xFFF8F6FB)
private val TextMuted = Color(0xFF85838C)
private val Red = Color(0xFFE53935)

private val es = Locale("es", "MX")

private fun prettyDate(date: LocalDate): String =
    date.format(DateTimeFormatter.ofPattern("EEEE d 'de' MMMM", es)).replaceFirstChar { it.uppercase() }

private fun prettyMonth(month: YearMonth): String =
    month.month.getDisplayName(TextStyle.FULL, es).replaceFirstChar { it.uppercase() }

data class AgendaEvent(
    val id: String = UUID.randomUUID().toString(),
    val date: String,
    val title: String,
    val time: String,
    val description: String,
    val color: String = "blue",
    val reminder: Boolean = false
)

data class Note(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val body: String,
    val pinned: Boolean = false,
    val date: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
)

data class DeletedNote(val note: Note, val deletedAt: Long = System.currentTimeMillis())

class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("agenda_store", Context.MODE_PRIVATE)

    fun events(): List<AgendaEvent> = runCatching {
        val a = JSONArray(prefs.getString("events", "[]"))
        (0 until a.length()).map { o ->
            val x = a.getJSONObject(o)
            AgendaEvent(x.optString("id"), x.optString("date"), x.optString("title"), x.optString("time"), x.optString("description"), x.optString("color", "blue"), x.optBoolean("reminder"))
        }
    }.getOrDefault(emptyList())

    fun saveEvents(items: List<AgendaEvent>) {
        val a = JSONArray()
        items.forEach { e -> a.put(JSONObject().apply { put("id", e.id); put("date", e.date); put("title", e.title); put("time", e.time); put("description", e.description); put("color", e.color); put("reminder", e.reminder) }) }
        prefs.edit().putString("events", a.toString()).apply()
    }

    fun notes(): List<Note> = runCatching {
        val a = JSONArray(prefs.getString("notes", "[]"))
        (0 until a.length()).map { i ->
            val x = a.getJSONObject(i)
            Note(x.optString("id"), x.optString("title"), x.optString("body"), x.optBoolean("pinned"), x.optString("date").ifBlank { null }, x.optLong("updatedAt", System.currentTimeMillis()))
        }
    }.getOrDefault(emptyList())

    fun saveNotes(items: List<Note>) {
        val a = JSONArray()
        items.forEach { n -> a.put(JSONObject().apply { put("id", n.id); put("title", n.title); put("body", n.body); put("pinned", n.pinned); put("date", n.date ?: ""); put("updatedAt", n.updatedAt) }) }
        prefs.edit().putString("notes", a.toString()).apply()
    }

    fun deletedNotes(): List<DeletedNote> = runCatching {
        val a = JSONArray(prefs.getString("deleted_notes", "[]"))
        (0 until a.length()).map { i ->
            val x = a.getJSONObject(i)
            val n = Note(x.optString("id"), x.optString("title"), x.optString("body"), x.optBoolean("pinned"), x.optString("date").ifBlank { null }, x.optLong("updatedAt"))
            DeletedNote(n, x.optLong("deletedAt"))
        }
    }.getOrDefault(emptyList())

    fun saveDeletedNotes(items: List<DeletedNote>) {
        val a = JSONArray()
        items.forEach { d -> a.put(JSONObject().apply { put("id", d.note.id); put("title", d.note.title); put("body", d.note.body); put("pinned", d.note.pinned); put("date", d.note.date ?: ""); put("updatedAt", d.note.updatedAt); put("deletedAt", d.deletedAt) }) }
        prefs.edit().putString("deleted_notes", a.toString()).apply()
    }

    fun dark() = prefs.getBoolean("dark", false)
    fun setDark(v: Boolean) { prefs.edit().putBoolean("dark", v).apply() }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AgendaApp(LocalStore(this)) }
    }
}

@Composable
fun AgendaApp(store: LocalStore) {
    var dark by remember { mutableStateOf(store.dark()) }
    var tab by remember { mutableIntStateOf(0) }
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    var month by remember { mutableStateOf(YearMonth.now()) }
    var events by remember { mutableStateOf(store.events()) }
    var notes by remember { mutableStateOf(store.notes()) }
    var deleted by remember { mutableStateOf(store.deletedNotes()) }
    var menuOpen by remember { mutableStateOf(false) }
    var panelOpen by remember { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }
    var driveOpen by remember { mutableStateOf(false) }
    var quickOpen by remember { mutableStateOf(false) }
    var deletedOpen by remember { mutableStateOf(false) }
    var editorNote by remember { mutableStateOf<Note?>(null) }
    var editorEvent by remember { mutableStateOf<AgendaEvent?>(null) }
    var fullScreenNote by remember { mutableStateOf<Note?>(null) }
    val context = LocalContext.current

    val createBackup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            val payload = JSONObject().apply {
                put("version", 1)
                put("events", JSONArray().apply { events.forEach { e -> put(JSONObject().apply { put("id", e.id); put("date", e.date); put("title", e.title); put("time", e.time); put("description", e.description); put("color", e.color); put("reminder", e.reminder) }) } })
                put("notes", JSONArray().apply { notes.forEach { n -> put(JSONObject().apply { put("id", n.id); put("title", n.title); put("body", n.body); put("pinned", n.pinned); put("date", n.date ?: ""); put("updatedAt", n.updatedAt) }) } })
            }.toString(2)
            runCatching { context.contentResolver.openOutputStream(uri)?.use { output -> output.write(payload.toByteArray()) } }
        }
    }

    val scheme = if (dark) darkColorScheme(primary = Blue) else lightColorScheme(primary = Blue)
    MaterialTheme(colorScheme = scheme) {
        Scaffold(
            containerColor = if (dark) Color(0xFF111116) else Page,
            bottomBar = { BottomNavigationBar(tab) { tab = it } }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Header(onMenu = { menuOpen = true }, onPanel = { panelOpen = true }, onSettings = { settingsOpen = true }, onRocket = { quickOpen = true })
                WorkspaceSelector(onClick = { menuOpen = true })
                if (tab == 0) {
                    CalendarScreen(
                        month, selectedDate, events, notes,
                        onPrevious = { month = month.minusMonths(1) }, onNext = { month = month.plusMonths(1) }, onDateSelected = { selectedDate = it },
                        onNewEvent = { editorEvent = AgendaEvent(date = selectedDate.toString(), title = "", time = "09:00 – 10:00", description = "") },
                        onNewNote = { editorNote = Note(title = "", body = "", date = selectedDate.toString()) },
                        onEditEvent = { editorEvent = it }, onEditNote = { fullScreenNote = it },
                        onDeleteEvent = { events = events.filterNot { e -> e.id == it.id }; store.saveEvents(events) },
                        onDeleteNote = { n -> notes = notes.filterNot { it.id == n.id }; deleted = (deleted + DeletedNote(n)).takeLast(100); store.saveNotes(notes); store.saveDeletedNotes(deleted) }
                    )
                } else {
                    NotesScreen(
                        notes = notes,
                        onNew = { editorNote = Note(title = "", body = "") },
                        onEdit = { fullScreenNote = it },
                        onDelete = { n -> notes = notes.filterNot { it.id == n.id }; deleted = (deleted + DeletedNote(n)).takeLast(100); store.saveNotes(notes); store.saveDeletedNotes(deleted) },
                        onPin = { n -> notes = notes.map { if (it.id == n.id) it.copy(pinned = !it.pinned, updatedAt = System.currentTimeMillis()) else it }; store.saveNotes(notes) }
                    )
                }
            }
        }
    }

    if (menuOpen) AppMenu(
        onDismiss = { menuOpen = false },
        onCalendar = { menuOpen = false; tab = 0 }, onNotes = { menuOpen = false; tab = 1 },
        onDeleted = { menuOpen = false; deletedOpen = true }, onPanel = { menuOpen = false; panelOpen = true },
        onDrive = { menuOpen = false; driveOpen = true }, onSettings = { menuOpen = false; settingsOpen = true }
    )
    if (panelOpen) PanelDialog(events, notes, onDismiss = { panelOpen = false })
    if (settingsOpen) SettingsDialog(dark, { dark = it; store.setDark(it) }, { settingsOpen = false })
    if (quickOpen) QuickActionsDialog(
        onNewEvent = { quickOpen = false; editorEvent = AgendaEvent(date = selectedDate.toString(), title = "", time = "09:00 – 10:00", description = "") },
        onNewNote = { quickOpen = false; editorNote = Note(title = "", body = "", date = selectedDate.toString()) },
        onDrive = { quickOpen = false; driveOpen = true }, onDismiss = { quickOpen = false }
    )
    if (driveOpen) DriveDialog(onBackup = { createBackup.launch("AgendaInteligente_backup.json") }, onDismiss = { driveOpen = false })
    if (deletedOpen) DeletedNotesDialog(
        deleted = deleted,
        onRestore = { d -> deleted = deleted.filterNot { it.note.id == d.note.id }; notes = (notes + d.note).distinctBy { it.id }.sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.updatedAt }); store.saveDeletedNotes(deleted); store.saveNotes(notes) },
        onPermanentDelete = { d -> deleted = deleted.filterNot { it.note.id == d.note.id }; store.saveDeletedNotes(deleted) },
        onDismiss = { deletedOpen = false }
    )
    editorEvent?.let { original -> EventDialog(original, { editorEvent = null }) { edited -> events = (events.filterNot { it.id == edited.id } + edited).sortedWith(compareBy<AgendaEvent> { it.date }.thenBy { it.time }); store.saveEvents(events); editorEvent = null } }
    editorNote?.let { original -> NoteDialog(original, { editorNote = null }) { edited -> notes = (notes.filterNot { it.id == edited.id } + edited).sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.updatedAt }); store.saveNotes(notes); editorNote = null } }
    fullScreenNote?.let { note -> FullScreenNote(note, onClose = { fullScreenNote = null }, onSave = { edited -> notes = (notes.filterNot { it.id == edited.id } + edited).sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.updatedAt }); store.saveNotes(notes); fullScreenNote = null }, onDelete = { n -> notes = notes.filterNot { it.id == n.id }; deleted = (deleted + DeletedNote(n)).takeLast(100); store.saveNotes(notes); store.saveDeletedNotes(deleted); fullScreenNote = null }) }
}

@Composable
fun Header(onMenu: () -> Unit, onPanel: () -> Unit, onSettings: () -> Unit, onRocket: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(72.dp).background(MaterialTheme.colorScheme.surface).padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(shape = CircleShape, color = Orange, modifier = Modifier.size(38.dp).clickable { onMenu() }) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.EventAvailable, null, tint = Color.White) } }
        Spacer(Modifier.width(12.dp))
        Surface(shape = RoundedCornerShape(9.dp), color = Color(0xFFE9E7E2), modifier = Modifier.clickable { onMenu() }) { Text("Avance", Modifier.padding(horizontal = 13.dp, vertical = 8.dp), fontSize = 15.sp, fontWeight = FontWeight.Medium) }
        Text("Panel", Modifier.padding(horizontal = 12.dp).clickable { onPanel() }, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.weight(1f))
        IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Configuración") }
        Surface(shape = RoundedCornerShape(9.dp), color = Color(0xFF111111), modifier = Modifier.size(44.dp)) { IconButton(onClick = onRocket) { Icon(Icons.Default.RocketLaunch, "Acciones rápidas", tint = Color.White) } }
    }
}

@Composable
fun WorkspaceSelector(onClick: () -> Unit) {
    Surface(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 9.dp).clickable { onClick() }, shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Sync, null, tint = TextMuted, modifier = Modifier.size(21.dp)); Spacer(Modifier.width(14.dp)); Text("Hogar", fontSize = 18.sp); Spacer(Modifier.weight(1f)); Icon(Icons.Default.KeyboardArrowDown, null, tint = TextMuted)
        }
    }
}

@Composable
fun CalendarScreen(month: YearMonth, selectedDate: LocalDate, events: List<AgendaEvent>, notes: List<Note>, onPrevious: () -> Unit, onNext: () -> Unit, onDateSelected: (LocalDate) -> Unit, onNewEvent: () -> Unit, onNewNote: () -> Unit, onEditEvent: (AgendaEvent) -> Unit, onEditNote: (Note) -> Unit, onDeleteEvent: (AgendaEvent) -> Unit, onDeleteNote: (Note) -> Unit) {
    val dayEvents = events.filter { it.date == selectedDate.toString() }.sortedBy { it.time }
    val dayNotes = notes.filter { it.date == selectedDate.toString() }
    Column(Modifier.fillMaxSize()) {
        Text("MI AGENDA", Modifier.padding(start = 24.dp, top = 30.dp), fontSize = 13.sp, color = TextMuted, fontWeight = FontWeight.Bold)
        Text("Calendario", Modifier.padding(start = 24.dp, top = 3.dp), fontSize = 38.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        Surface(Modifier.padding(horizontal = 20.dp), shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onPrevious) { Icon(Icons.Default.ChevronLeft, null, tint = Blue, modifier = Modifier.size(30.dp)) }; Text("${prettyMonth(month)} ${month.year}", Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 22.sp); IconButton(onClick = onNext) { Icon(Icons.Default.ChevronRight, null, tint = Blue, modifier = Modifier.size(30.dp)) } }
                CalendarGrid(month, selectedDate, events, notes, onDateSelected)
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    LegendDot(Blue, "Eventos"); LegendDot(Purple, "Notas"); LegendDot(Orange, "Ambos")
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(prettyDate(selectedDate), Modifier.padding(horizontal = 28.dp), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Blue)
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onNewEvent, Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(26.dp)) { Icon(Icons.Default.Event, null); Spacer(Modifier.width(6.dp)); Text("Evento") }
            Button(onClick = onNewNote, Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(26.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange)) { Icon(Icons.Default.NoteAdd, null); Spacer(Modifier.width(6.dp)); Text("Nota") }
        }
        TimelineDay(
            selectedDate = selectedDate,
            events = dayEvents,
            notes = dayNotes,
            onEditEvent = onEditEvent,
            onDeleteEvent = onDeleteEvent,
            onEditNote = onEditNote,
            onDeleteNote = onDeleteNote
        )
    }
}

@Composable
fun TimelineDay(
    selectedDate: LocalDate,
    events: List<AgendaEvent>,
    notes: List<Note>,
    onEditEvent: (AgendaEvent) -> Unit,
    onDeleteEvent: (AgendaEvent) -> Unit,
    onEditNote: (Note) -> Unit,
    onDeleteNote: (Note) -> Unit
) {
    val total = events.size + notes.size
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Timeline del día", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("${prettyDate(selectedDate)} · $total ${if (total == 1) "actividad" else "actividades"}", fontSize = 13.sp, color = TextMuted)
            }
            Icon(Icons.Default.Schedule, null, tint = Blue)
        }
        if (total == 0) {
            Surface(Modifier.fillMaxWidth().padding(vertical = 8.dp), shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface) {
                Text("No hay actividades para este día. Usa Evento o Nota para agregar una.", Modifier.padding(18.dp), color = TextMuted)
            }
        } else {
            LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = 24.dp)) {
                items(events, key = { "timeline_event_${it.id}" }) { event ->
                    TimelineEventRow(event, onEditEvent, onDeleteEvent)
                }
                items(notes, key = { "timeline_note_${it.id}" }) { note ->
                    TimelineNoteRow(note, onEditNote, onDeleteNote)
                }
            }
        }
    }
}

@Composable
fun TimelineEventRow(event: AgendaEvent, onEdit: (AgendaEvent) -> Unit, onDelete: (AgendaEvent) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(58.dp)) {
            Text(if (event.time.isBlank()) "--:--" else event.time, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextMuted)
            Box(Modifier.padding(top = 5.dp).size(11.dp).clip(CircleShape).background(Blue))
            Box(Modifier.width(2.dp).height(70.dp).background(Blue.copy(alpha = 0.25f)))
        }
        Surface(Modifier.weight(1f).clickable { onEdit(event) }, shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(5.dp).height(46.dp).clip(RoundedCornerShape(4.dp)).background(if (event.color == "orange") Orange else Blue))
                Column(Modifier.padding(start = 11.dp).weight(1f)) {
                    Text(event.title.ifBlank { "Evento" }, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    if (event.description.isNotBlank()) Text(event.description, fontSize = 13.sp, color = TextMuted, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = { onDelete(event) }) { Icon(Icons.Default.DeleteOutline, null, tint = Red) }
            }
        }
    }
}

@Composable
fun TimelineNoteRow(note: Note, onEdit: (Note) -> Unit, onDelete: (Note) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(58.dp)) {
            Text("Día", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextMuted)
            Box(Modifier.padding(top = 5.dp).size(11.dp).clip(CircleShape).background(Purple))
            Box(Modifier.width(2.dp).height(70.dp).background(Purple.copy(alpha = 0.25f)))
        }
        Surface(Modifier.weight(1f).clickable { onEdit(note) }, shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(5.dp).height(46.dp).clip(RoundedCornerShape(4.dp)).background(Purple))
                Column(Modifier.padding(start = 11.dp).weight(1f)) {
                    Text(note.title.ifBlank { "Nota" }, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    if (note.body.isNotBlank()) Text(note.body, fontSize = 13.sp, color = TextMuted, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = { onDelete(note) }) { Icon(Icons.Default.DeleteOutline, null, tint = Red) }
            }
        }
    }
}

@Composable
fun CalendarGrid(month: YearMonth, selectedDate: LocalDate, events: List<AgendaEvent>, notes: List<Note>, onDateSelected: (LocalDate) -> Unit) {
    val first = month.atDay(1); val start = first.dayOfWeek.value % 7; val headers = listOf("D", "L", "M", "X", "J", "V", "S")
    Column {
        Row(Modifier.fillMaxWidth()) { headers.forEachIndexed { index, h -> val selectedHeader = selectedDate.month == month.month && selectedDate.year == month.year && selectedDate.dayOfWeek.value % 7 == index; Surface(Modifier.weight(1f).padding(2.dp), shape = RoundedCornerShape(12.dp), color = if (selectedHeader) Blue else Color.Transparent) { Text(h, Modifier.padding(vertical = 6.dp), textAlign = TextAlign.Center, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (selectedHeader) Color.White else TextMuted) } } }
        Spacer(Modifier.height(4.dp)); var day = 1
        repeat(6) { week -> Row(Modifier.fillMaxWidth().height(58.dp)) { repeat(7) { col -> val index = week * 7 + col; Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) { if (index >= start && day <= month.lengthOfMonth()) { val date = month.atDay(day); val selected = date == selectedDate; val today = date == LocalDate.now(); val hasEvent = events.any { it.date == date.toString() }; val hasNote = notes.any { it.date == date.toString() }; val both = hasEvent && hasNote; Column(horizontalAlignment = Alignment.CenterHorizontally) { Box(Modifier.size(if (selected) 40.dp else 36.dp).clip(CircleShape).background(if (selected) Blue else if (today) Color(0xFFE7F0FF) else Color.Transparent).clickable { onDateSelected(date) }, contentAlignment = Alignment.Center) { Text(day.toString(), color = if (selected) Color.White else if (today) Blue else MaterialTheme.colorScheme.onSurface, fontSize = 15.sp, fontWeight = if (selected || today) FontWeight.Bold else FontWeight.Normal) }; Row(horizontalArrangement = Arrangement.spacedBy(3.dp), modifier = Modifier.padding(top = 2.dp)) { if (hasEvent) Box(Modifier.size(4.dp).clip(CircleShape).background(if (both) Orange else Blue)); if (hasNote) Box(Modifier.size(4.dp).clip(CircleShape).background(if (both) Orange else Purple)) } }; day++ } } } }
    }
}

@Composable fun LegendDot(color: Color, text: String) { Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(7.dp).clip(CircleShape).background(color)); Spacer(Modifier.width(4.dp)); Text(text, fontSize = 11.sp, color = TextMuted) } }
@Composable fun SectionLabel(text: String) { Text(text, Modifier.padding(horizontal = 28.dp, vertical = 8.dp), fontSize = 12.sp, color = TextMuted, fontWeight = FontWeight.Bold) }

@Composable
fun EventCard(event: AgendaEvent, onEdit: (AgendaEvent) -> Unit, onDelete: (AgendaEvent) -> Unit) { Surface(Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 5.dp).clickable { onEdit(event) }, shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surface) { Row(Modifier.height(IntrinsicSize.Min)) { Box(Modifier.width(6.dp).fillMaxHeight().background(if (event.color == "orange") Orange else Blue)); Column(Modifier.padding(15.dp).weight(1f)) { if (event.time.isNotBlank()) Text(event.time, color = TextMuted, fontSize = 13.sp); Text(event.title, fontSize = 16.sp, fontWeight = FontWeight.Bold); if (event.description.isNotBlank()) Text(event.description, Modifier.padding(top = 5.dp), color = TextMuted, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis) }; IconButton(onClick = { onDelete(event) }) { Icon(Icons.Default.DeleteOutline, null, tint = Red) } } } }

@Composable
fun NotesScreen(notes: List<Note>, onNew: () -> Unit, onEdit: (Note) -> Unit, onDelete: (Note) -> Unit, onPin: (Note) -> Unit) {
    var query by remember { mutableStateOf("") }; val filtered = notes.filter { it.title.contains(query, true) || it.body.contains(query, true) }
    Column(Modifier.fillMaxSize()) { Text("NOTAS", Modifier.padding(start = 24.dp, top = 30.dp), fontSize = 13.sp, color = TextMuted, fontWeight = FontWeight.Bold); Text("Notas", Modifier.padding(start = 24.dp, top = 3.dp), fontSize = 38.sp, fontWeight = FontWeight.Bold); OutlinedTextField(query, { query = it }, placeholder = { Text("Buscar notas") }, leadingIcon = { Icon(Icons.Default.Search, null) }, modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp).height(58.dp), shape = RoundedCornerShape(30.dp), colors = OutlinedTextFieldDefaults.colors(unfocusedContainerColor = MaterialTheme.colorScheme.surface, focusedContainerColor = MaterialTheme.colorScheme.surface, unfocusedBorderColor = Color.Transparent), singleLine = true); Button(onClick = onNew, Modifier.fillMaxWidth().padding(horizontal = 20.dp).height(58.dp), shape = RoundedCornerShape(29.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Nueva nota", fontSize = 19.sp, fontWeight = FontWeight.Bold) }; Text("NOTAS", Modifier.padding(start = 26.dp, top = 20.dp, bottom = 6.dp), fontSize = 12.sp, color = TextMuted, fontWeight = FontWeight.Bold); LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) { items(filtered, key = { it.id }) { NoteCard(it, onEdit, onDelete, onPin) } } }
}

@Composable
fun NoteCard(note: Note, onEdit: (Note) -> Unit, onDelete: (Note) -> Unit, onPin: (Note) -> Unit) { Surface(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp).clickable { onEdit(note) }, shape = RoundedCornerShape(23.dp), color = MaterialTheme.colorScheme.surface) { Column(Modifier.padding(18.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Text(note.title.ifBlank { "Sin título" }, Modifier.weight(1f), fontSize = 19.sp, fontWeight = FontWeight.Bold); IconButton(onClick = { onPin(note) }) { Icon(Icons.Default.PushPin, "Fijar", tint = if (note.pinned) Orange else TextMuted) }; IconButton(onClick = { onDelete(note) }) { Icon(Icons.Default.DeleteOutline, "Eliminar", tint = Red) } }; Text(note.body, Modifier.padding(top = 2.dp), color = TextMuted, fontSize = 15.sp, lineHeight = 22.sp, maxLines = 5, overflow = TextOverflow.Ellipsis); note.date?.let { Surface(Modifier.padding(top = 10.dp), shape = RoundedCornerShape(20.dp), color = Color(0xFFE7F0FF)) { Text(it, Modifier.padding(horizontal = 11.dp, vertical = 5.dp), color = Blue, fontSize = 12.sp) } } } } }

@Composable fun BottomNavigationBar(selected: Int, onSelect: (Int) -> Unit) { NavigationBar(containerColor = MaterialTheme.colorScheme.surface) { NavigationBarItem(selected == 0, { onSelect(0) }, icon = { Icon(Icons.Default.CalendarMonth, null) }, label = { Text("Calendario") }); NavigationBarItem(selected == 1, { onSelect(1) }, icon = { Icon(Icons.Default.Description, null) }, label = { Text("Notas") }) } }

@Composable
fun AppMenu(onDismiss: () -> Unit, onCalendar: () -> Unit, onNotes: () -> Unit, onDeleted: () -> Unit, onPanel: () -> Unit, onDrive: () -> Unit, onSettings: () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) { Surface(Modifier.fillMaxHeight().fillMaxWidth(0.86f), color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(topEnd = 28.dp, bottomEnd = 28.dp)) { Column(Modifier.fillMaxSize().padding(20.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Surface(Modifier.size(54.dp), CircleShape, color = Orange) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.EventAvailable, null, tint = Color.White) } }; Spacer(Modifier.width(12.dp)); Column { Text("Agenda Inteligente", fontSize = 19.sp, fontWeight = FontWeight.Bold); Text("Organiza tu día", fontSize = 12.sp, color = TextMuted) } }; Spacer(Modifier.height(20.dp)); MenuItem(Icons.Default.Home, "Inicio", onCalendar); MenuItem(Icons.Default.CalendarMonth, "Calendario", onCalendar); MenuItem(Icons.Default.Description, "Notas", onNotes); MenuItem(Icons.Default.DeleteOutline, "Notas eliminadas", onDeleted); MenuItem(Icons.Default.Dashboard, "Panel", onPanel); HorizontalDivider(Modifier.padding(vertical = 10.dp)); MenuItem(Icons.Default.CloudUpload, "Sincronizar con Google Drive", onDrive); MenuItem(Icons.Default.Settings, "Configuración", onSettings); Spacer(Modifier.weight(1f)); Text("v4.0 • Agenda Inteligente", color = TextMuted, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally)) } } }
}

@Composable fun MenuItem(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, onClick: () -> Unit) { Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { onClick() }.padding(horizontal = 12.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Blue); Spacer(Modifier.width(14.dp)); Text(text, fontSize = 16.sp) } }

@Composable fun PanelDialog(events: List<AgendaEvent>, notes: List<Note>, onDismiss: () -> Unit) { AlertDialog(onDismissRequest = onDismiss, title = { Text("Tu resumen") }, text = { Column(verticalArrangement = Arrangement.spacedBy(12.dp)) { Text("Eventos guardados: ${events.size}"); Text("Notas totales: ${notes.size}"); Text("Notas fijadas: ${notes.count { it.pinned }}"); Text("Días con actividad este mes: ${notes.mapNotNull { it.date }.toSet().size + events.map { it.date }.toSet().size}", color = TextMuted) } }, confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } }) }

@Composable fun QuickActionsDialog(onNewEvent: () -> Unit, onNewNote: () -> Unit, onDrive: () -> Unit, onDismiss: () -> Unit) { AlertDialog(onDismissRequest = onDismiss, title = { Text("Acciones rápidas") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Button(onClick = onNewEvent, Modifier.fillMaxWidth()) { Icon(Icons.Default.Event, null); Spacer(Modifier.width(8.dp)); Text("Nuevo evento") }; Button(onClick = onNewNote, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Orange)) { Icon(Icons.Default.NoteAdd, null); Spacer(Modifier.width(8.dp)); Text("Nueva nota") }; OutlinedButton(onClick = onDrive, Modifier.fillMaxWidth()) { Icon(Icons.Default.CloudUpload, null); Spacer(Modifier.width(8.dp)); Text("Sincronizar / respaldo") } } }, confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } }) }

@Composable fun DriveDialog(onBackup: () -> Unit, onDismiss: () -> Unit) { AlertDialog(onDismissRequest = onDismiss, title = { Text("Sincronización con Google Drive") }, text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) { Icon(Icons.Default.Cloud, null, tint = Blue, modifier = Modifier.size(48.dp)); Text("Guarda una copia de tus eventos y notas en Google Drive."); Text("Android te permitirá elegir la carpeta o ubicación de Drive. Después podrás conservar el archivo de respaldo y recuperarlo cuando lo necesites.", color = TextMuted, fontSize = 13.sp) } }, confirmButton = { Button(onClick = onBackup) { Text("Guardar en Drive") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } }) }

@Composable fun SettingsDialog(dark: Boolean, onDark: (Boolean) -> Unit, onDismiss: () -> Unit) { AlertDialog(onDismissRequest = onDismiss, title = { Text("Configuración") }, text = { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Icon(if (dark) Icons.Default.DarkMode else Icons.Default.LightMode, null); Spacer(Modifier.width(12.dp)); Text("Modo oscuro", Modifier.weight(1f)); Switch(dark, onDark) } }, confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } }) }

@Composable
fun DeletedNotesDialog(deleted: List<DeletedNote>, onRestore: (DeletedNote) -> Unit, onPermanentDelete: (DeletedNote) -> Unit, onDismiss: () -> Unit) {
    val now = System.currentTimeMillis(); val kept = deleted.filter { now - it.deletedAt < 180L * 24 * 60 * 60 * 1000 }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Notas eliminadas") }, text = { Column(Modifier.fillMaxWidth().heightIn(max = 430.dp)) { if (kept.isEmpty()) Text("No hay notas eliminadas.", color = TextMuted) else LazyColumn { items(kept, key = { it.note.id }) { d -> Surface(Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(15.dp), color = MaterialTheme.colorScheme.surfaceVariant) { Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.DeleteOutline, null, tint = Red); Spacer(Modifier.width(8.dp)); Column(Modifier.weight(1f)) { Text(d.note.title.ifBlank { "Sin título" }, fontWeight = FontWeight.Bold); Text("Se conserva 180 días", fontSize = 11.sp, color = TextMuted) }; TextButton(onClick = { onRestore(d) }) { Text("Restaurar") }; IconButton(onClick = { onPermanentDelete(d) }) { Icon(Icons.Default.DeleteForever, "Eliminar definitivamente", tint = Red) } } } } } } }, confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } })
}

@Composable
fun FullScreenNote(note: Note, onClose: () -> Unit, onSave: (Note) -> Unit, onDelete: (Note) -> Unit) {
    var title by remember(note.id) { mutableStateOf(note.title) }; var body by remember(note.id) { mutableStateOf(note.body) }; var pinned by remember(note.id) { mutableStateOf(note.pinned) }; var date by remember(note.id) { mutableStateOf(note.date ?: "") }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) { Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { Column(Modifier.fillMaxSize()) { Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onClose) { Icon(Icons.Default.ArrowBack, "Cerrar") }; Text(if (note.title.isBlank()) "Nueva nota" else "Nota", Modifier.weight(1f), fontSize = 20.sp, fontWeight = FontWeight.Bold); IconButton(onClick = { onDelete(note) }) { Icon(Icons.Default.DeleteOutline, "Eliminar", tint = Red) } }; HorizontalDivider(); Column(Modifier.fillMaxSize().padding(18.dp)) { OutlinedTextField(title, { title = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Título") }, singleLine = true); Spacer(Modifier.height(12.dp)); OutlinedTextField(body, { body = it }, Modifier.fillMaxWidth().weight(1f), label = { Text("Contenido") }, textStyle = LocalTextStyle.current.copy(fontSize = 18.sp), minLines = 12); Spacer(Modifier.height(10.dp)); OutlinedTextField(date, { date = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Fecha (AAAA-MM-DD, opcional)") }, singleLine = true); Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(pinned, { pinned = it }); Text("Fijar nota") }; Button(onClick = { val valid = title.isNotBlank() && (date.isBlank() || runCatching { LocalDate.parse(date) }.isSuccess); if (valid) onSave(note.copy(title = title, body = body, pinned = pinned, date = date.ifBlank { null }, updatedAt = System.currentTimeMillis())) }, Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(27.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("Guardar", fontSize = 17.sp, fontWeight = FontWeight.Bold) } } } } }
}

@Composable
fun EventDialog(original: AgendaEvent, onDismiss: () -> Unit, onSave: (AgendaEvent) -> Unit) { var title by remember { mutableStateOf(original.title) }; var time by remember { mutableStateOf(original.time) }; var date by remember { mutableStateOf(original.date) }; var desc by remember { mutableStateOf(original.description) }; var reminder by remember { mutableStateOf(original.reminder) }; AlertDialog(onDismissRequest = onDismiss, title = { Text(if (original.title.isBlank()) "Nuevo evento" else "Editar evento") }, text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) { OutlinedTextField(title, { title = it }, label = { Text("Título") }, singleLine = true); OutlinedTextField(date, { date = it }, label = { Text("Fecha (AAAA-MM-DD)") }, singleLine = true); OutlinedTextField(time, { time = it }, label = { Text("Horario") }, singleLine = true); OutlinedTextField(desc, { desc = it }, label = { Text("Descripción") }, minLines = 3); Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(reminder, { reminder = it }); Text("Recordatorio") } } }, confirmButton = { TextButton(onClick = { if (title.isNotBlank() && runCatching { LocalDate.parse(date) }.isSuccess) onSave(original.copy(title = title, date = date, time = time, description = desc, reminder = reminder)) }) { Text("Guardar") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }) }

@Composable
fun NoteDialog(original: Note, onDismiss: () -> Unit, onSave: (Note) -> Unit) { var title by remember { mutableStateOf(original.title) }; var body by remember { mutableStateOf(original.body) }; var pinned by remember { mutableStateOf(original.pinned) }; var date by remember { mutableStateOf(original.date ?: "") }; AlertDialog(onDismissRequest = onDismiss, title = { Text(if (original.title.isBlank()) "Nueva nota" else "Editar nota") }, text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) { OutlinedTextField(title, { title = it }, label = { Text("Título") }, singleLine = true); OutlinedTextField(body, { body = it }, label = { Text("Contenido") }, minLines = 5); OutlinedTextField(date, { date = it }, label = { Text("Fecha (AAAA-MM-DD, opcional)") }, singleLine = true); Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(pinned, { pinned = it }); Text("Fijar nota") } } }, confirmButton = { TextButton(onClick = { val valid = title.isNotBlank() && (date.isBlank() || runCatching { LocalDate.parse(date) }.isSuccess); if (valid) onSave(original.copy(title = title, body = body, pinned = pinned, date = date.ifBlank { null }, updatedAt = System.currentTimeMillis())) }) { Text("Guardar") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }) }
}
