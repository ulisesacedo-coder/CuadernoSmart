# Agenda S V20 — Hábitos con unidades

Esta versión amplía los hábitos para permitir seleccionar una unidad de medida desde una lista desplegable.

Unidades incluidas: mL, L, oz líquidas, vasos, tazas, segundos, minutos, horas, metros, kilómetros, millas, pasos, repeticiones, veces, sesiones, páginas, palabras, porciones, piezas, pisos, kcal, kg y lb.

Los hábitos existentes de versiones anteriores conservan compatibilidad: agua se migra a L y los hábitos de tiempo a min cuando no tenían unidad guardada.

La meta, el progreso diario, el calendario y las estadísticas semanales utilizan la unidad seleccionada.
